
  ______                        _______________ 
 /_  __/__  ____ _____ ___     / ____/ ____/   |
  / / / _ \/ __ `/ __ `__ \   / __/ / /_  / /| |
 / / /  __/ /_/ / / / / / /  / /___/ __/ / ___ |
/_/  \___/\__,_/_/ /_/ /_/  /_____/_/   /_/  |_|



[*] Crack Notes

    Copy patch folder program to original file directory and replace it.

[*] Update log
=======================
2022.10
=======================
Updates & Bugs Fixed:
Library Editor:
Library sort didn’t work right after renaming column
CAD Interfaces:
KiCad: crashes building PADS-to-CAD parts
3D STEP Output:
Step file was not saving to selected output directory in some cases for most CAD tools
Options:
Terminals > Surface Mount > Inward L Flat Ribbon – had duplicate terminal option
Components > Through-hole > Mounting Holes had an unnecessary dropdown for Origin
Turning off Drafting > Courtyard > Add Outline to Footprint did not work as intended
Components > Surface Mount > SODFL/SOFL pin 1, 2 and more than 2 pins added
FP Designer:
Creating a Thermal Pad with a paste mask pattern, the Pad Stack Manger threw Exception errors when changing the Shape
Calculators:
QFN – the silkscreen outline was not adhering to the Clearance Option
LCC – The pad length calculations need to be adjusted
QFN with Thermal – Rotating the footprint so Pin 1 is Upper Left but the thermal chamfer was in Lower Left
Removed the “SMD Pad Stack Rules” panel from all Through-hole calculators
=======================
2022.09
=======================
Updates & Bugs Fixed:
License: 
Updated the HASP license to allow Footprint Expert to run as a Viewer if the HL or SL is are not found on startup or connection with key is lost 
FP Designer:
Batch build FP Designer parts with an offset origin that caused the pins to move
Options:
Drafting > Component Outlines > turning off the “Output to CAD” turned the outline off in the viewer
FP Designer – Pad Stack Designer for Through-hole hole size calculations not synced with Terminal Options
Chip courtyard not sizing correctly for micro-mini parts
Calculators: 
Removed the “SMD Pad Stack Rules” panel from all SMD Grid Array calculators.
=======================
2022.08
=======================
Updates & Bugs Fixed:
Options:
Drafting Outlines – Assembly polarity indicator option changed to on as Default
Silkscreen polarity dot default options changed to most = 0.60, nom = 0.50, least = 0.40
BGA and CGA default percent values changed to reflect IPC-7351B pad size calculation
Options 'Ask to Save' message pops up redundantly on program close
Terminals > Grid Array > BGA – updated the pad reduction percentages to match IPC-7351B pad sizes
Calculators:
DPAK – orientation changed to match dimension reference drawing
2-Pin Packages SMD & PTH – updated the assembly polarity marking to lower left to be consistent with semiconductor assembly polarity marking
BGA – silkscreen outline not closing; dot not relocating correctly when rotated
BGA – when using the min/max dimensions only and mapping the Assembly Outline to the Nominal body caused errors
Problem with silkscreen for AE Caps and DFN2's when terminal widths get too large or silkscreen maps to minimum body
DFN3 and DPAK Tabs now treated as signal pins instead of thermal tabs
DFN silkscreen over pads in some parts with wide lead spacing
Library Editor:
Added trap for illegal ASCII characters in library edits, helps prevent FPX files from getting corrupted
Library 'Find' function doesn't work after translating a part
Date formatted info not loading correctly from library sometimes
Library sort – pasted cells go to the end
Importing libraries with missing footprint dates not working
FP Designer:
Rotation, Mirror and Polarity Dot functions not working correctly
Pin import function not functioning correctly
CAD Tool Interfaces:
Xpedition menu not showing the Component Outline layer selection option
Allegro and OrCAD PCB 3D files not saving to the correct folder
Miscellaneous:
Programs crashes when opening with FPX double-click
=======================
2022.07
=======================
Updates & Bugs Fixed:
Calculators: 
BGA – fixed an issue with loading a non-collapsing BGA from an FPX library
DPAK – added 7 and 9-pin versions
Side Concave Package – fixed silkscreen and assembly polarity indicators
DFN 4 – fixed polarity indicators
All Component Families – when all pins are hidden program threw a Handled Exception error
Miscellaneous:
Program wouldn’t run in a read only directory
Library Editor:
Updated the column sort feature for the Date column
FP Designer: 
Moving origin didn’t work in Mil units
Proteus:
Fixed an issue with the CAD tool interface not working
=======================
2022.06
=======================
Updates & Bugs Fixed:
Calculators:
Corner Concave Oscillator did not have automatic silkscreen & assembly pin 1 polarity markings
FP Designer: 
Resizing thermal pad paste mask checker-board pattern in the Pad Stack Manager caused corruption
Options:
New Feature – relocated the automatic Pin 1 polarity dot to the left of Pin 1 for all footprints that have pads outside the package body
Turning off component outline and terminals still produced them in the exported footprint
License: 
Fixed issue for FIPS enabled computers
Library Editor:
Selecting the header columns did not sort the data correctly
3D STEP:
Users could not rename 3D STEP files in the translator UI
=======================
2022.05
=======================
Updates & Bugs Fixed:
FPX File Converter:
Not updating FP Designer outline on/off selections
Courtyard excess for FP Designer footprints were incorrect
Options:
Drafting – Text for terminal and body outline text mismatch
Updated Console Options – put the Component Outline to the top of the layer list
Library Editor:
Library not adding copied parts to the end of the list
Calculators:
SOT143 – pin reordering did not allow for fat pin on any pin except #1
4-Sided Chip Array – mfr. recommended footprint pattern, the G1 was not applied correctly
2-Sided Chip Array – courtyard was not resizing to include silkscreen outline
SOT23 – corrected the Gang Mask feature
SOP’s & QFP’s with thermal tabs – fixed pads under body not trimming correctly
Right Angle Shrouded Header – silkscreen not conforming to body outline
Through-hole Right Angle Post Header – fixed and issue with the Pin 1 polarity dot and line
FP Designer:
Pad Stack Manager paste mask percent % not displaying value
Triangle symbol size now matches V2020
The “Add to Library” button was not enabling after editing drafting symbols
Courtyard contoured outline not forming to some rotated pad stacks
Export .CSV file defaulted to Tab delimiter, and it was changed to Comma delimiter
CAD Interfaces:
Xpedition - Create and Close and circle back and Create did not work
OrCAD PCB - Designer Basics user option issue with not saving
PADS Layout -
Multipart (Batch Build) Part Type file was not generated correctly
KiCad -
Not putting Batch Built files in library folder
Fixed a Reference Designator line width issue
Added Rounded Rectangle pad shape