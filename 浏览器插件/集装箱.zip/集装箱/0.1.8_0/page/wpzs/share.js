siteUi.initMenu("wpzs_share");

siteUi.addonReady(function () {
    layui.use(["element"]);
});