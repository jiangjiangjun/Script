siteUi.initMenu("wpzs_info");

siteUi.addonReady(function () {
    layui.use(["element"]);
});