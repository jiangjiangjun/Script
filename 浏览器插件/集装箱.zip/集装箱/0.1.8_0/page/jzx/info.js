siteUi.initMenu("jzx_info");

siteUi.addonReady(function () {
    layui.use(["element", "form"]);
});