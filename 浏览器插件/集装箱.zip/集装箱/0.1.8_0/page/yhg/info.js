siteUi.initMenu("yhg_info");

siteUi.addonReady(function () {
    layui.use(["element"]);
});