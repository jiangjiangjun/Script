siteUi.initMenu("yhg_option");

siteUi.addonReady(function () {
    layui.use(["element", "form"]);
});