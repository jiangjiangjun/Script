siteUi.initMenu("gain_xzws");

siteUi.addonReady(function () {
    layui.use(["element", "form"]);
});