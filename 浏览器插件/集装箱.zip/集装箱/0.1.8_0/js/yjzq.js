(function () {
    var container = (function () {
        var obj = {
            module_defines: {},
            module_objects: {}
        };

        obj.define = function (name, requires, callback) {
            name = obj.processName(name);
            obj.module_defines[name] = {
                requires: requires,
                callback: callback
            };
        };

        obj.require = function (name, cache) {
            if (typeof cache == "undefined") {
                cache = true;
            }

            name = obj.processName(name);
            if (cache && obj.module_objects.hasOwnProperty(name)) {
                return obj.module_objects[name];
            }
            else if (obj.module_defines.hasOwnProperty(name)) {
                var requires = obj.module_defines[name].requires;
                var callback = obj.module_defines[name].callback;

                var module = obj.use(requires, callback);
                cache && obj.register(name, module);
                return module;
            }
        };

        obj.use = function (requires, callback) {
            var module = {
                exports: {}
            };
            var params = obj.buildParams(requires, module);
            var result = callback.apply(this, params);
            if (typeof result != "undefined") {
                return result;
            }
            else {
                return module.exports;
            }
        };

        obj.register = function (name, module) {
            name = obj.processName(name);
            obj.module_objects[name] = module;
        };

        obj.buildParams = function (requires, module) {
            var params = [];
            requires.forEach(function (name) {
                params.push(obj.require(name));
            });
            params.push(obj.require);
            params.push(module.exports);
            params.push(module);
            return params;
        };

        obj.processName = function (name) {
            return name.toLowerCase();
        };

        return {
            define: obj.define,
            use: obj.use,
            register: obj.register,
            modules: obj.module_objects
        };
    })();

    container.define("addon", [], function () {
        if (typeof browser == "undefined") {
            return chrome;
        }
        else {
            return browser;
        }
    });

    container.define("message_addon", ["addon"], function (addon) {
        var obj = {
            message_listeners: {}
        };

        obj.onMessage = function (name, listener) {
            obj.message_listeners[name] = listener;
        };

        obj.postMessage = function (name, data, callback) {
            var port = addon.runtime.connect({ name: name });
            callback && port.onMessage.addListener(callback);
            port.postMessage(data);
        };

        obj.handleMessage = function (port) {
            if (obj.message_listeners.hasOwnProperty(port.name)) {
                var connected = true;
                var listener = obj.message_listeners[port.name];
                var callback = function (response) {
                    connected && port.postMessage(response);
                };
                port.onMessage.addListener(function (data) {
                    listener && listener(data, callback);
                });
                port.onDisconnect.addListener(function () {
                    connected = false;
                });
            }
        };

        obj.init = function () {
            addon.runtime.onConnect.addListener(obj.handleMessage);
        };

        return obj.init(), {
            onMessage: obj.onMessage,
            postMessage: obj.postMessage
        };
    });

    container.define("menu", ["message_addon"], function (messageAddon) {
        var obj = {
            option: [],
            search_text: "",
            aria_text: ""
        };

        obj.init = function (option, searchText, ariaText) {
            obj.option = option;
            obj.search_text = searchText;
            obj.aria_text = ariaText;
        };

        obj.getOption = function () {
            return obj.option;
        };

        obj.setOption = function (option) {
            obj.option = option;
            obj.syncMenuOption();
        };

        obj.getSearchText = function () {
            return obj.search_text;
        };

        obj.setSearchText = function (searchText) {
            obj.search_text = searchText;
            obj.syncMenuOption();
        };

        obj.getAriaText = function () {
            return obj.aria_text;
        };

        obj.setAriaText = function (ariaText) {
            obj.aria_text = ariaText;
            obj.syncMenuOption();
        };

        obj.syncMenuOption = function () {
            var data = {
                option: obj.getOption(),
                search_text: obj.getSearchText(),
                aria_text: obj.getAriaText()
            };
            messageAddon.postMessage("set_menu_option", data);
        };

        return obj;
    });

    container.define("core", ["message_addon", "menu"], function (messageAddon, menu) {
        var obj = {};

        obj.ready = function (callback) {
            messageAddon.postMessage("get_menu_option", {}, function (response) {
                menu.init(response.option, response.search_text, response.aria_text);
                callback && callback();
            });
        };

        return obj;
    });

    container.define("app", ["menu", "vue"], function (menu, vue) {
        var obj = {};

        obj.run = function () {
            new vue({
                el: "#container",
                data: {
                    search_text: menu.getSearchText(),
                    aria_text: menu.getAriaText(),
                    option: menu.getOption()
                },
                created: function () {
                    layui.use(["element", "form"]);
                },
                watch: {
                    search_text: function (value) {
                        menu.setSearchText(value);
                    },
                    aria_text: function (value) {
                        menu.setAriaText(value);
                    },
                    option: function (value) {
                        menu.setOption(value);
                    }
                }
            });
        };

        return obj;
    });

    container.define("$", [], function () {
        return window.$;
    });
    container.define("vue", [], function () {
        return window.Vue;
    });

    container.use(["core", "app"], function (core, app) {
        core.ready(app.run);
    });

})();