(function () {
    var container = (function () {
        var obj = {
            module_defines: {},
            module_objects: {}
        };

        obj.define = function (name, requires, callback) {
            name = obj.processName(name);
            obj.module_defines[name] = {
                requires: requires,
                callback: callback
            };
        };

        obj.require = function (name, cache) {
            if (typeof cache == "undefined") {
                cache = true;
            }

            name = obj.processName(name);
            if (cache && obj.module_objects.hasOwnProperty(name)) {
                return obj.module_objects[name];
            }
            else if (obj.module_defines.hasOwnProperty(name)) {
                var requires = obj.module_defines[name].requires;
                var callback = obj.module_defines[name].callback;

                var module = obj.use(requires, callback);
                cache && obj.register(name, module);
                return module;
            }
        };

        obj.use = function (requires, callback) {
            var module = {
                exports: {}
            };
            var params = obj.buildParams(requires, module);
            var result = callback.apply(this, params);
            if (typeof result != "undefined") {
                return result;
            }
            else {
                return module.exports;
            }
        };

        obj.register = function (name, module) {
            name = obj.processName(name);
            obj.module_objects[name] = module;
        };

        obj.buildParams = function (requires, module) {
            var params = [];
            requires.forEach(function (name) {
                params.push(obj.require(name));
            });
            params.push(obj.require);
            params.push(module.exports);
            params.push(module);
            return params;
        };

        obj.processName = function (name) {
            return name.toLowerCase();
        };

        return {
            define: obj.define,
            use: obj.use,
            register: obj.register,
            modules: obj.module_objects
        };
    })();

    container.define("http", ["$"], function ($) {
        var obj = {};

        obj.ajax = function (option) {
            $.ajax(option);
        };
        return {
            ajax: obj.ajax
        };
    });

    container.define("core", [], function () {
        var obj = {};

        obj.ready = function (callback) {
            callback && callback();
        };

        return obj;
    });

    container.define("api", ["http"], function (http) {
        var obj = {
            base: "http://api.newday.me"
        };

        obj.getCouponBenefit = function (callback) {
            http.ajax({
                url: obj.base + "/share/coupon/benefit",
                type: "post",
                dataType: "json",
                success: function (response) {
                    callback && callback(response);
                },
                error: function (e) {
                    callback && callback("");
                }
            });
        }

        return obj;
    });

    container.define("app", ["api", "vue", "$"], function (api, vue, $) {
        var obj = {};

        obj.run = function () {
            new vue({
                el: "#container",
                data: {
                    benefit_html: ""
                },
                created: function () {
                    layui.use(["element", "form"]);

                    this.initBenefit();
                },
                methods: {
                    initBenefit: function () {
                        var $this = this;
                        api.getCouponBenefit(function (response) {
                            if (response && response.code == 1) {
                                $this.benefit_html = response.data.benefit_html;
                            }
                        });
                    },
                    showQrcode: function (url) {
                        var qr = qrcode(12, "M");
                        qr.addData(url);
                        qr.make();
                        layer.open({
                            type: 1,
                            title: "二维码",
                            skin: "layui-layer-rim",
                            content: "<div style='padding: 10px;'>" + qr.createImgTag(4, 2) + "</div>"
                        });
                        setTimeout(function () {
                            $(".layui-layer-close").removeAttr("href");
                        }, 500);
                    }
                }
            });
        };

        return obj;
    });

    container.define("$", [], function () {
        return window.$;
    });
    container.define("vue", [], function () {
        return window.Vue;
    });

    container.use(["core", "app"], function (core, app) {
        core.ready(app.run);
    });

})();