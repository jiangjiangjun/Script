(function () {
    var container = (function () {
        var obj = {
            module_defines: {},
            module_objects: {}
        };

        obj.define = function (name, requires, callback) {
            name = obj.processName(name);
            obj.module_defines[name] = {
                requires: requires,
                callback: callback
            };
        };

        obj.require = function (name, cache) {
            if (typeof cache == "undefined") {
                cache = true;
            }

            name = obj.processName(name);
            if (cache && obj.module_objects.hasOwnProperty(name)) {
                return obj.module_objects[name];
            }
            else if (obj.module_defines.hasOwnProperty(name)) {
                var requires = obj.module_defines[name].requires;
                var callback = obj.module_defines[name].callback;

                var module = obj.use(requires, callback);
                cache && obj.register(name, module);
                return module;
            }
        };

        obj.use = function (requires, callback) {
            var module = {
                exports: {}
            };
            var params = obj.buildParams(requires, module);
            var result = callback.apply(this, params);
            if (typeof result != "undefined") {
                return result;
            }
            else {
                return module.exports;
            }
        };

        obj.register = function (name, module) {
            name = obj.processName(name);
            obj.module_objects[name] = module;
        };

        obj.buildParams = function (requires, module) {
            var params = [];
            requires.forEach(function (name) {
                params.push(obj.require(name));
            });
            params.push(obj.require);
            params.push(module.exports);
            params.push(module);
            return params;
        };

        obj.processName = function (name) {
            return name.toLowerCase();
        };

        return {
            define: obj.define,
            use: obj.use,
            register: obj.register,
            modules: obj.module_objects
        };
    })();

    container.define("addon", [], function () {
        if (typeof browser == "undefined") {
            return chrome;
        }
        else {
            return browser;
        }
    });

    container.define("object", [], function () {
        var obj = {};

        obj.keys = function (data) {
            var list = [];
            for (var key in data) {
                list.push(key);
            }
            return list;
        };

        obj.values = function (data) {
            var list = [];
            for (var key in data) {
                list.push(data[key]);
            }
            return list;
        };

        return obj;
    });

    container.define("runtime", [], function () {
        var obj = {
            url: location.href,
            referer: document.referrer,
        };

        obj.getUrl = function () {
            return obj.url;
        };

        obj.setUrl = function (url) {
            obj.url = url;
        };

        obj.getReferer = function () {
            return obj.referer;
        };

        obj.setReferer = function (referer) {
            obj.referer = referer;
        };

        obj.getUrlParam = function (name) {
            var param = obj.parseUrlParam(obj.getUrl());
            if (name) {
                return param.hasOwnProperty(name) ? param[name] : null;
            }
            else {
                return param;
            }
        };

        obj.parseUrlParam = function (url) {
            if (url.indexOf("?")) {
                url = url.split("?")[1];
            }
            var reg = /([^=&\s]+)[=\s]*([^=&\s]*)/g;
            var obj = {};
            while (reg.exec(url)) {
                obj[RegExp.$1] = RegExp.$2;
            }
            return obj;
        };

        return obj;
    });

    container.define("storage", [], function () {
        var obj = {};

        obj.getValue = function (name) {
            return window.localStorage[name];
        };

        obj.setValue = function (name, value) {
            window.localStorage[name] = value;
        };

        obj.getValueList = function () {
            var valueList = {};
            var i, name;
            for (i = 0; i < localStorage.length; i++) {
                name = localStorage.key(i);
                valueList[name] = localStorage[name];
            }
            return valueList;
        };

        return obj;
    });

    container.define("config", ["storage"], function (storage) {
        var obj = {
            name: "configJson"
        };

        obj.getConfig = function (name) {
            var configJson = storage.getValue(obj.name);
            var configObject = obj.parseJson(configJson);
            if (name) {
                return configObject.hasOwnProperty(name) ? configObject[name] : null;
            }
            else {
                return configObject;
            }
        };

        obj.setConfig = function (name, value) {
            var configObject = obj.getConfig();
            configObject[name] = value;
            storage.setValue(obj.name, JSON.stringify(configObject));
        };

        obj.parseJson = function (jsonStr) {
            var jsonObject = {};
            try {
                if (jsonStr) {
                    jsonObject = JSON.parse(jsonStr);
                }
            }
            catch (e) { }
            return jsonObject;
        };

        return obj;
    });

    container.define("mode", [], function () {
        var obj = {
            constant: {
                addon: "addon",
                script: "script"
            }
        };

        obj.getMode = function () {
            return obj.constant.addon;
        };

        return obj;
    });

    container.define("user", ["storage"], function (storage) {
        var obj = {};

        obj.getUid = function () {
            var uid = storage.getValue("uid");
            if (!uid) {
                uid = storage.getValue("_uid_");
            }
            if (!uid) {
                uid = obj.randString(32);
                storage.setValue("uid", uid);
            }
            return uid;
        };

        obj.randString = function (length) {
            var possible = "abcdefghijklmnopqrstuvwxyz0123456789";
            var text = "";
            for (var i = 0; i < length; i++) {
                text += possible.charAt(Math.floor(Math.random() * possible.length));
            }
            return text;
        };

        return obj;
    });

    container.define("browser", [], function () {
        var obj = {
            constant: {
                firefox: "firefox",
                edge: "edge",
                baidu: "baidu",
                liebao: "liebao",
                uc: "uc",
                qq: "qq",
                sogou: "sogou",
                opera: "opera",
                maxthon: "maxthon",
                ie2345: "2345",
                se360: "360",
                chrome: "chrome",
                safari: "safari",
                other: "other"
            }
        };

        obj.getBrowser = function () {
            return obj.matchBrowserType(navigator.userAgent);
        };

        obj.matchBrowserType = function (userAgent) {
            var browser = obj.constant.other;
            userAgent = userAgent.toLowerCase();
            if (userAgent.match(/firefox/) != null) {
                browser = obj.constant.firefox;
            } else if (userAgent.match(/edge/) != null) {
                browser = obj.constant.edge;
            } else if (userAgent.match(/bidubrowser/) != null) {
                browser = obj.constant.baidu;
            } else if (userAgent.match(/lbbrowser/) != null) {
                browser = obj.constant.liebao;
            } else if (userAgent.match(/ubrowser/) != null) {
                browser = obj.constant.uc;
            } else if (userAgent.match(/qqbrowse/) != null) {
                browser = obj.constant.qq;
            } else if (userAgent.match(/metasr/) != null) {
                browser = obj.constant.sogou;
            } else if (userAgent.match(/opr/) != null) {
                browser = obj.constant.opera;
            } else if (userAgent.match(/maxthon/) != null) {
                browser = obj.constant.maxthon;
            } else if (userAgent.match(/2345explorer/) != null) {
                browser = obj.constant.ie2345;
            } else if (userAgent.match(/chrome/) != null) {
                if (obj.existMime("type", "application/vnd.chromium.remoting-viewer")) {
                    browser = obj.constant.se360;
                } else {
                    browser = obj.constant.chrome;
                }
            } else if (userAgent.match(/safari/) != null) {
                browser = obj.constant.safari;
            }
            return browser;
        };

        obj.existMime = function (option, value) {
            if (typeof navigator != "undefined") {
                var mimeTypes = navigator.mimeTypes;
                for (var mt in mimeTypes) {
                    if (mimeTypes[mt][option] == value) {
                        return true;
                    }
                }
            }
            return false;
        };

        return obj;
    });

    container.define("env", ["addon", "mode", "user", "browser"], function (addon, mode, user, browser) {
        var obj = {};

        obj.getMode = function () {
            return mode.getMode();
        };

        obj.getAid = function () {
            return addon.runtime.id;
        };

        obj.getUid = function () {
            return user.getUid();
        };

        obj.getVersion = function () {
            var manifest = addon.runtime.getManifest();
            return manifest.version;
        };

        obj.getBrowser = function () {
            return browser.getBrowser();
        };

        obj.getInfo = function () {
            return {
                mode: obj.getMode(),
                aid: obj.getAid(),
                uid: obj.getUid(),
                version: obj.getVersion(),
                browser: obj.getBrowser()
            };
        };

        return obj;
    });

    container.define("crypto", ["CryptoJS"], function (CryptoJS) {
        var obj = {};

        obj.md5 = function (str) {
            return CryptoJS.MD5(str).toString();
        };

        obj.aesEncode = function (str, password) {
            var hash = obj.md5(password);
            var key = CryptoJS.enc.Utf8.parse(hash.substring(2, 18));
            var iv = CryptoJS.enc.Utf8.parse(hash.substring(14, 30));

            var encrypted = '';
            var srcs = CryptoJS.enc.Utf8.parse(str);
            encrypted = CryptoJS.AES.encrypt(srcs, key, {
                iv: iv,
                mode: CryptoJS.mode.CBC,
                padding: CryptoJS.pad.ZeroPadding
            });
            return encrypted.ciphertext.toString();
        }

        obj.aesDecode = function (str, password) {
            var hash = obj.md5(password);
            var key = CryptoJS.enc.Utf8.parse(hash.substring(2, 18));
            var iv = CryptoJS.enc.Utf8.parse(hash.substring(14, 30));

            var encryptedHexStr = CryptoJS.enc.Hex.parse(str);
            var srcs = CryptoJS.enc.Base64.stringify(encryptedHexStr);
            var decrypt = CryptoJS.AES.decrypt(srcs, key, {
                iv: iv,
                mode: CryptoJS.mode.CBC,
                padding: CryptoJS.pad.ZeroPadding
            });
            var decryptedStr = decrypt.toString(CryptoJS.enc.Utf8);
            return decryptedStr.toString();
        }

        return obj;
    });

    container.define("http", ["crypto", "$"], function (crypto, $) {
        var obj = {
            password: "E80Z^fiYXuyWxw$!"
        };

        obj.ajax = function (option) {
            if (option.url.indexOf("api.newday.me") > 0 && option.data) {
                option.data = obj.decryptData(option.data);
            }
            $.ajax(option);
        };

        obj.decryptData = function (data) {
            var json = JSON.stringify(data);
            if (json) {
                return {
                    _payload_: crypto.aesEncode(json, obj.password)
                };
            }
            else {
                return data;
            }
        };

        return {
            ajax: obj.ajax
        };
    });

    container.define("router", ["addon"], function (addon) {
        var obj = {};

        obj.goUrl = function (url) {
            window.open(url);
        };

        obj.openUrl = function (url) {
            window.open(url);
        };

        obj.openTab = function (url, active) {
            addon.tabs.create({ url: url, active: active });
        };

        return obj;
    });

    container.define("calendar", ["object"], function (object) {
        var obj = {};

        obj.formatTime = function (timestamp, format) {
            timestamp || (timestamp = (new Date()).getTime());
            format || (format = "Y-m-d H:i:s");
            var date = new Date(timestamp);
            var year = 1900 + date.getYear();
            var month = "0" + (date.getMonth() + 1);
            var day = "0" + date.getDate();
            var hour = "0" + date.getHours();
            var minute = "0" + date.getMinutes();
            var second = "0" + date.getSeconds();
            var vars = {
                "Y": year,
                "m": month.substring(month.length - 2, month.length),
                "d": day.substring(day.length - 2, day.length),
                "H": hour.substring(hour.length - 2, hour.length),
                "i": minute.substring(minute.length - 2, minute.length),
                "s": second.substring(second.length - 2, second.length)
            };
            return obj.replaceVars(vars, format);
        };

        obj.replaceVars = function (vars, value) {
            object.keys(vars).forEach(function (key) {
                value = value.replace(key, vars[key]);
            });
            return value;
        };

        return obj;
    });

    container.define("loader", [], function () {
        var obj = {
            raw_caches: {}
        };

        obj.loadScript = function (urlList, callback) {
            obj.getRawContentBatch(urlList).then(function (result) {
                callback && callback({
                    result: result,
                    content: result.join(";")
                });
            });
        };

        obj.buildScript = function (templateList, libList, gmList, callback) {
            var promiseList = [
                obj.getRawContentBatch(templateList),
                obj.getRawContentBatch(libList),
                obj.getRawContentBatch(gmList)
            ];
            Promise.all(promiseList).then(function (result) {
                var templateCode = result[0].join(";");
                var thirdLibrary = result[1].join(";");
                var userScript = result[2].join(";");

                var content = templateCode;
                content = obj.replaceScript("'##third_library##'", thirdLibrary, content);
                content = obj.replaceScript("'##user_script##'", userScript, content);

                callback({
                    result: result,
                    content: content
                });
            });
        };

        obj.replaceScript = function (pattern, replace, script) {
            var divideList = script.split(pattern);
            return divideList[0] + replace + divideList[1];
        };

        obj.getRawContentBatch = function (urlList) {
            return new Promise(function (resolve) {
                var promiseList = [];
                urlList.forEach(function (url) {
                    promiseList.push(obj.getRawContent(url));
                });
                Promise.all(promiseList).then(function (result) {
                    resolve(result);
                });
            });
        };

        obj.getRawContent = function (url) {
            return new Promise(function (resolve) {
                if (!obj.raw_caches.hasOwnProperty(url)) {
                    obj.fetchRawContent(url, function (response) {
                        obj.raw_caches[url] = response;
                        resolve(obj.raw_caches[url]);
                    });
                }
                else {
                    resolve(obj.raw_caches[url]);
                }
            });
        };

        obj.fetchRawContent = function (url, callback) {
            var xhr = new XMLHttpRequest;
            xhr.open("GET", url, true);
            xhr.onreadystatechange = function () {
                if (xhr.readyState == XMLHttpRequest.DONE) {
                    callback && callback(xhr.responseText);
                }
            };
            xhr.send(null);
        };

        return obj;
    });

    container.define("message_addon", ["addon"], function (addon) {
        var obj = {
            message_listeners: {}
        };

        obj.onMessage = function (name, listener) {
            obj.message_listeners[name] = listener;
        };

        obj.postMessage = function (name, data, callback) {
            var port = addon.runtime.connect({ name: name });
            callback && port.onMessage.addListener(callback);
            port.postMessage(data);
        };

        obj.handleMessage = function (port) {
            if (obj.message_listeners.hasOwnProperty(port.name)) {
                var connected = true;
                var listener = obj.message_listeners[port.name];
                var callback = function (response) {
                    connected && port.postMessage(response);
                };
                port.onMessage.addListener(function (data) {
                    listener && listener(data, callback);
                });
                port.onDisconnect.addListener(function () {
                    connected = false;
                });
            }
        };

        obj.init = function () {
            addon.runtime.onConnect.addListener(obj.handleMessage);
        };

        return obj.init(), {
            onMessage: obj.onMessage,
            postMessage: obj.postMessage
        };
    });

    container.define("gm", ["addon", "storage"], function (addon, storage) {
        var obj = {};

        obj.getGmInfo = function () {
            var manifest = addon.runtime.getManifest();
            return {
                script: {
                    uuid: addon.runtime.id,
                    version: manifest.version
                },
                addon: {
                    id: addon.runtime.id,
                    options_page: manifest.options_page
                }
            };
        };

        obj.getGmValues = function () {
            return storage.getValueList();
        };

        return obj;
    });

    container.define("api", ["http", "env"], function (http, env) {
        var obj = {
            base: "https://api.newday.me"
        };

        obj.versionQuery = function (callback) {
            http.ajax({
                type: "post",
                url: obj.base + "/share/one/version",
                dataType: "json",
                data: {
                    mode: env.getMode(),
                    aid: env.getAid(),
                    uid: env.getUid(),
                    version: env.getVersion(),
                    browser: env.getBrowser()
                },
                success: function (response) {
                    callback && callback(response);
                },
                error: function (error) {
                    callback && callback("");
                }
            });
        };

        obj.proxyQuery = function (callback) {
            http.ajax({
                type: "post",
                url: obj.base + "/share/proxy/chrome",
                dataType: "json",
                data: {
                    mode: env.getMode(),
                    aid: env.getAid(),
                    uid: env.getUid(),
                    version: env.getVersion(),
                    browser: env.getBrowser()
                },
                success: function (response) {
                    callback && callback(response);
                },
                error: function (error) {
                    callback && callback("");
                }
            });
        };

        obj.queryBaiduImage = function (imageUrl, callback) {
            http.ajax({
                url: "https://graph.baidu.com/upload",
                type: "post",
                dateType: "json",
                data: {
                    image: imageUrl,
                    tn: "pc",
                    from: "pc",
                    image_source: "PC_UPLOAD_URL",
                    uptime: (new Date()).getTime()
                },
                success: function (response) {
                    callback && callback(response);
                },
                error: function () {
                    callback && callback("");
                }
            });
        }

        return obj;
    });

    container.define("updater", ["config", "env", "calendar", "api"], function (config, env, calendar, api) {
        var obj = {};

        obj.getLatest = function () {
            var versionLatest = config.getConfig("version_latest");
            if (versionLatest) {
                return versionLatest;
            }
            else {
                return env.getVersion();
            }
        };

        obj.init = function () {
            var currentDate = calendar.formatTime(null, "Ymd");
            api.versionQuery(function (response) {
                config.setConfig("version_date", currentDate);
                if (response && response.code == 1) {
                    config.setConfig("version_latest", response.data.version);
                }
            });
        };

        return obj;
    });

    container.define("proxy", ["addon", "storage", "browser", "api"], function (addon, storage, browser, api) {
        var obj = {};

        obj.init = function () {
            obj.initProxy();
        };

        obj.getStatus = function () {
            var proxyStatus = storage.getValue("proxy_status");
            if (proxyStatus != "no") {
                return "yes";
            }
            else {
                return "no";
            }
        };

        obj.setStatus = function (status) {
            if (status != "no") {
                storage.setValue("proxy_status", "yes");
            }
            else {
                storage.setValue("proxy_status", "no");
            }
        };

        obj.initProxy = function () {
            if (obj.getStatus() == "yes") {
                obj.activeProxy();
            }
            else {
                obj.clearProxy();
            }
        };

        obj.activeProxy = function () {
            api.proxyQuery(function (response) {
                var pacUrl;
                if (response && response.code == 1) {
                    pacUrl = response.data.pac_url;
                }
                else {
                    pacUrl = obj.getDefaultPacUrl();
                }
                obj.setPacProxy(pacUrl);
            });
        };

        obj.setPacProxy = function (pacUrl) {
            var settings;
            if (browser.getBrowser() == browser.constant.firefox) {
                settings = {
                    value: {
                        proxyType: "autoConfig",
                        autoConfigUrl: pacUrl
                    }
                };
            }
            else {
                settings = {
                    value: {
                        mode: "pac_script",
                        pacScript: {
                            mandatory: true,
                            url: pacUrl
                        }
                    },
                    scope: "regular"
                };
            }
            console.log(settings);
            obj.clearProxy(function () {
                addon.proxy.settings.set(settings);
            });
        };

        obj.clearProxy = function (callback) {
            addon.proxy.settings.clear({
                scope: "regular"
            }, callback);
        };

        obj.getDefaultPacUrl = function () {
            return "http://api.newday.me/share/proxy/pac.html";
        };

        return obj;
    });

    container.define("notify", ["addon"], function (addon) {
        var obj = {
            listener: {}
        };

        obj.showNotify = function (title, message, callback) {
            var id = obj.randString(32);
            obj.listener[id] = callback;
            addon.notifications.create(id, {
                "type": "basic",
                "iconUrl": addon.runtime.getURL("logo/logo_96.png"),
                "title": title,
                "message": message
            });
        };

        obj.randString = function (length) {
            var possible = "abcdefghijklmnopqrstuvwxyz0123456789";
            var text = "";
            for (var i = 0; i < length; i++) {
                text += possible.charAt(Math.floor(Math.random() * possible.length));
            }
            return text;
        };

        obj.init = function () {
            addon.notifications.onClicked.addListener(function (notificationId) {
                if (obj.listener.hasOwnProperty(notificationId)) {
                    obj.listener[notificationId] && obj.listener[notificationId]();
                    delete obj.listener[notificationId];
                }
            });
        };

        return obj.init(), obj;
    });

    container.define("command", ["addon", "router", "notify", "proxy"], function (addon, router, notify, proxy) {
        var obj = {
            tab_id: 0
        };

        obj.onToogleProxy = function () {
            var info;
            if (proxy.getStatus() == "yes") {
                proxy.setStatus("no");
                info = "已关闭谷歌代理";
            }
            else {
                proxy.setStatus("yes");
                info = "已启用谷歌代理";
            }
            notify.showNotify("集装箱", info, function () {
                router.openTab("/page/kxsw/ggzs.html", true);
            });
            proxy.initProxy();
        };

        obj.init = function () {
            addon.commands.onCommand.addListener(function (command) {
                switch (command) {
                    case "toggle-proxy":
                        obj.onToogleProxy();
                        break;
                }
            });
        };

        return obj;
    });

    container.define("option", ["object", "storage"], function (object, storage) {
        return function (name, constant) {
            var obj = {
                name: name,
                constant: constant
            };

            obj.isOptionActive = function (item) {
                var name = item.name;
                var option = obj.getOption();
                return option.indexOf(name) >= 0 ? true : false;
            };

            obj.setOptionActive = function (item) {
                var name = item.name;
                var option = obj.getOption();
                if (option.indexOf(name) < 0) {
                    option.push(name);
                    obj.setOption(option);
                }
            };

            obj.setOptionUnActive = function (item) {
                var name = item.name;
                var option = obj.getOption();
                var index = option.indexOf(name);
                if (index >= 0) {
                    delete option[index];
                    obj.setOption(option);
                }
            };

            obj.getOption = function () {
                var option = [];
                var optionJson = storage.getValue(obj.name);
                var optionObject = obj.parseJson(optionJson);
                object.values(obj.constant).forEach(function (item) {
                    var name = item.name;
                    if (optionObject.hasOwnProperty(name)) {
                        if (optionObject[name] != "no") {
                            option.push(name);
                        }
                    }
                    else if (item.value != "no") {
                        option.push(name);
                    }
                });
                return option;
            };

            obj.setOption = function (option) {
                var optionObject = {};
                object.values(obj.constant).forEach(function (item) {
                    var name = item.name;
                    if (option.indexOf(name) >= 0) {
                        optionObject[name] = "yes";
                    } else {
                        optionObject[name] = "no";
                    }
                });
                storage.setValue(obj.name, JSON.stringify(optionObject));
            };

            obj.parseJson = function (jsonStr) {
                var jsonObject = {};
                try {
                    if (jsonStr) {
                        jsonObject = JSON.parse(jsonStr);
                    }
                }
                catch (e) { }
                return jsonObject;
            };

            return obj;
        };
    });

    container.define("cookie", ["addon"], function (addon) {
        var obj = {};

        obj.getUrlCookieStr = function (url, callback) {
            obj.getUrlCookieList(url, function (data) {
                var str = "";
                for (var i in data) {
                    str += data[i]["name"] + "=" + decodeURIComponent(data[i]["value"]) + "; ";
                }
                callback && callback(str);
            });
        };

        obj.getUrlCookieList = function (url, callback) {
            obj.matchUrlCookieList(url, function (response) {
                var data = [];
                response.forEach(function (item) {
                    data.push({
                        domain: item.domain,
                        name: item.name,
                        value: item.value,
                        path: item.path,
                        expirationDate: item.expirationDate,
                        secure: item.secure,
                        httpOnly: item.httpOnly
                    });
                });
                callback && callback(data);
            });
        };

        obj.matchUrlCookieList = function (url, callback) {
            addon.cookies.getAll({
                url: url
            }, callback);
        };

        return obj;
    });

    container.define("aria", ["cookie", "http", "crypto", "runtime"], function (cookie, http, crypto, runtime) {
        var obj = {};

        obj.addTask = function (domain, url, server, token, callback) {
            cookie.getUrlCookieStr(domain, function (cookieStr) {
                var rpcObj = {
                    jsonrpc: "2.0",
                    method: "aria2.addUri",
                    id: crypto.md5(url),
                    params: [
                        "token:" + token,
                        [url],
                        {
                            header: [
                                "Cookie: " + cookieStr,
                                "User-Agent: " + navigator.userAgent,
                                "Connection: keep-alive"
                            ],
                            out: obj.parseFileName(url)
                        }
                    ]
                };
                var rpcJson = JSON.stringify(rpcObj);
                http.ajax({
                    url: server,
                    data: rpcJson,
                    type: "post",
                    dataType: "json",
                    success: function (response) {
                        callback && callback(response);
                    },
                    error: function () {
                        callback && callback("");
                    }
                })
            });
        };

        obj.parseFileName = function (url) {
            var param = runtime.parseUrlParam(url);
            if (param.filename) {
                return decodeURIComponent(param.filename);
            }
            else if (param.zipname) {
                return decodeURIComponent(param.zipname);
            }
            return "";
        };

        return obj;
    });

    container.define("menu", ["addon", "config", "router", "browser", "notify", "option", "aria", "api"], function (addon, config, router, browser, notify, option, aria, api) {
        var obj = {
            option: null,
            search_text: "search_text",
            aria_text: "aria_text"
        };

        obj.getSearchText = function () {
            return config.getConfig(obj.search_text);
        };

        obj.setSearchText = function (text) {
            config.setConfig(obj.search_text, text);
        };

        obj.getAriaText = function () {
            return config.getConfig(obj.aria_text);
        };

        obj.setAriaText = function (text) {
            config.setConfig(obj.aria_text, text);
        };

        obj.getMenuConstant = function () {
            var menuMapping = obj.getMenuMapping();
            var menuConstant = {};
            for (var i in menuMapping) {
                if (!menuMapping[i].diy) {
                    menuConstant[i] = {
                        name: i,
                        value: menuMapping[i].default
                    };
                }
            }
            return menuConstant;
        };

        obj.getMenuOption = function () {
            if (!obj.option) {
                obj.option = option("menuOptionJson", obj.getMenuConstant());
            }
            return obj.option;
        };

        obj.getSearchMenuList = function () {
            var menuList = [
                {
                    id: "search_google",
                    type: "link",
                    title: "使用谷歌搜索\"%s\"",
                    contexts: ["selection"],
                    payload: {
                        url: "https://www.google.com/search?q=%s"
                    },
                    default: "yes"
                },
                {
                    id: "search_baidu",
                    type: "link",
                    title: "使用百度搜索\"%s\"",
                    contexts: ["selection"],
                    payload: {
                        url: "https://www.baidu.com/s?wd=%s&ie=utf-8"
                    },
                    default: "yes"
                },
                {
                    id: "search_so",
                    type: "link",
                    title: "使用360搜索\"%s\"",
                    contexts: ["selection"],
                    payload: {
                        url: "https://www.so.com/s?q=%s"
                    },
                    default: "yes"
                },
                {
                    id: "search_sogou",
                    type: "link",
                    title: "使用搜狗搜索\"%s\"",
                    contexts: ["selection"],
                    payload: {
                        url: "https://www.sogou.com/web?query=%s"
                    },
                    default: "no"
                },
                {
                    id: "search_bing",
                    type: "link",
                    title: "使用必应搜索\"%s\"",
                    contexts: ["selection"],
                    payload: {
                        url: "https://www.bing.com/search?q=%s"
                    },
                    default: "no"
                },
                {
                    id: "search_yahoo",
                    type: "link",
                    title: "使用雅虎搜索\"%s\"",
                    contexts: ["selection"],
                    payload: {
                        url: "https://search.yahoo.com/search?p=%s"
                    },
                    default: "no"
                }
            ];
            return {
                title: "搜索引擎",
                list: menuList
            };
        };

        obj.getShopSearchMenuList = function () {
            var menuList = [
                {
                    id: "shop_taobao",
                    type: "link",
                    title: "使用淘宝搜索\"%s\"",
                    contexts: ["selection"],
                    payload: {
                        url: "https://s.taobao.com/search?q=%s"
                    },
                    default: "yes"
                },
                {
                    id: "shop_jd",
                    type: "link",
                    title: "使用京东搜索\"%s\"",
                    contexts: ["selection"],
                    payload: {
                        url: "https://search.jd.com/Search?keyword=%s&enc=utf-8"
                    },
                    default: "yes"
                },
                {
                    id: "shop_kaola",
                    type: "link",
                    title: "使用考拉搜索\"%s\"",
                    contexts: ["selection"],
                    payload: {
                        url: "https://search.kaola.com/search.html?key=%s"
                    },
                    default: "no"
                },
                {
                    id: "shop_amazon",
                    type: "link",
                    title: "使用亚马逊搜索\"%s\"",
                    contexts: ["selection"],
                    payload: {
                        url: "https://www.amazon.cn/s?k=%s"
                    },
                    default: "no"
                },
                {
                    id: "shop_suning",
                    type: "link",
                    title: "使用苏宁搜索\"%s\"",
                    contexts: ["selection"],
                    payload: {
                        url: "https://search.suning.com/%s/"
                    },
                    default: "no"
                },
                {
                    id: "shop_gome",
                    type: "link",
                    title: "使用国美搜索\"%s\"",
                    contexts: ["selection"],
                    payload: {
                        url: "https://search.gome.com.cn/search?question=%s"
                    },
                    default: "no"
                },
                {
                    id: "shop_dangdang",
                    type: "link",
                    title: "使用当当搜索\"%s\"",
                    contexts: ["selection"],
                    payload: {
                        url: "http://search.dangdang.com/?key=%s&act=input"
                    },
                    default: "no"
                }
            ];
            return {
                title: "商城搜索",
                list: menuList
            };
        };

        obj.getImageSearchMenuList = function () {
            var menuList = [
                {
                    id: "search_similar_google",
                    type: "search_similar_google",
                    title: "使用谷歌搜索相似图片",
                    contexts: ["image"],
                    payload: {
                        url: "https://www.google.com/searchbyimage?image_url=%s"
                    }
                },
                {
                    id: "search_similar_baidu",
                    type: "search_similar_baidu",
                    title: "使用百度搜索相似图片",
                    contexts: ["image"],
                    payload: {
                    }
                }
            ];
            return {
                title: "相似图片",
                list: menuList
            };
        };

        obj.getSocialSearchMenuList = function () {
            var menuList = [
                {
                    id: "social_weibo",
                    type: "link",
                    title: "使用微博搜索\"%s\"",
                    contexts: ["selection"],
                    payload: {
                        url: "https://s.weibo.com/weibo/%s"
                    },
                    default: "yes"
                },
                {
                    id: "social_zhihu",
                    type: "link",
                    title: "使用知乎搜索\"%s\"",
                    contexts: ["selection"],
                    payload: {
                        url: "https://www.zhihu.com/search?type=content&q=%s"
                    },
                    default: "yes"
                },
                {
                    id: "social_douban",
                    type: "link",
                    title: "使用豆瓣搜索\"%s\"",
                    contexts: ["selection"],
                    payload: {
                        url: "https://www.douban.com/search?q=%s"
                    },
                    default: "no"
                },
                {
                    id: "social_tieba",
                    type: "link",
                    title: "使用贴吧搜索\"%s\"",
                    contexts: ["selection"],
                    payload: {
                        url: "http://tieba.baidu.com/f?ie=utf-8&kw=%s"
                    },
                    default: "no"
                },
                {
                    id: "social_weixin",
                    type: "link",
                    title: "使用微信搜索\"%s\"",
                    contexts: ["selection"],
                    payload: {
                        url: "https://weixin.sogou.com/weixin?type=2&s_from=input&query=%s"
                    },
                    default: "no"
                }
            ];
            return {
                title: "社交搜索",
                list: menuList
            };
        };

        obj.getVideoSearchMenuList = function () {
            var menuList = [
                {
                    id: "video_iqiyi",
                    type: "link",
                    title: "使用爱奇艺搜索\"%s\"",
                    contexts: ["selection"],
                    payload: {
                        url: "https://so.iqiyi.com/so/q_%s"
                    },
                    default: "yes"
                },
                {
                    id: "video_youtube",
                    type: "link",
                    title: "使用YouTube搜索\"%s\"",
                    contexts: ["selection"],
                    payload: {
                        url: "https://www.youtube.com/results?search_query=%s"
                    },
                    default: "no"
                },
                {
                    id: "video_bilibili",
                    type: "link",
                    title: "使用哔哩哔哩搜索\"%s\"",
                    contexts: ["selection"],
                    payload: {
                        url: "https://search.bilibili.com/all?keyword=%s"
                    },
                    default: "yes"
                },
                {
                    id: "video_acfun",
                    type: "link",
                    title: "使用AcFun搜索\"%s\"",
                    contexts: ["selection"],
                    payload: {
                        url: "https://www.acfun.cn/search/#query=%s"
                    },
                    default: "no"
                },
                {
                    id: "video_youku",
                    type: "link",
                    title: "使用优酷搜索\"%s\"",
                    contexts: ["selection"],
                    payload: {
                        url: "https://so.youku.com/search_video/q_%s"
                    },
                    default: "no"
                },
                {
                    id: "video_qq",
                    type: "link",
                    title: "使用腾讯视频搜索\"%s\"",
                    contexts: ["selection"],
                    payload: {
                        url: "https://v.qq.com/x/search/?q=%s"
                    },
                    default: "no"
                },
                {
                    id: "video_yinyuetai",
                    type: "link",
                    title: "使用音悦台搜索\"%s\"",
                    contexts: ["selection"],
                    payload: {
                        url: "http://so.yinyuetai.com/?keyword=%s"
                    },
                    default: "no"
                },
                {
                    id: "video_mgtv",
                    type: "link",
                    title: "使用芒果TV搜索\"%s\"",
                    contexts: ["selection"],
                    payload: {
                        url: "https://so.mgtv.com/so/k-%s"
                    },
                    default: "no"
                }
            ];
            return {
                title: "视频搜索",
                list: menuList
            };
        };

        obj.getMusicSearchMenuList = function () {
            var menuList = [
                {
                    id: "music_163",
                    type: "link",
                    title: "使用网易云搜索\"%s\"",
                    contexts: ["selection"],
                    payload: {
                        url: "https://music.163.com/#/search/m/?s=%s&type=1"
                    },
                    default: "yes"
                },
                {
                    id: "music_kugou",
                    type: "link",
                    title: "使用酷狗搜索\"%s\"",
                    contexts: ["selection"],
                    payload: {
                        url: "https://www.kugou.com/yy/html/search.html#searchType=song&searchKeyWord=%s"
                    },
                    default: "yes"
                },
                {
                    id: "music_qq",
                    type: "link",
                    title: "使用QQ音乐搜索\"%s\"",
                    contexts: ["selection"],
                    payload: {
                        url: "https://y.qq.com/portal/search.html#w=%s"
                    },
                    default: "yes"
                },
                {
                    id: "music_xiami",
                    type: "link",
                    title: "使用虾米搜索\"%s\"",
                    contexts: ["selection"],
                    payload: {
                        url: "https://www.xiami.com/search?key=%s"
                    },
                    default: "no"
                },
                {
                    id: "music_kuwo",
                    type: "link",
                    title: "使用酷我搜索\"%s\"",
                    contexts: ["selection"],
                    payload: {
                        url: "http://www.kuwo.cn/search/list?key=%s"
                    },
                    default: "no"
                },
                {
                    id: "music_taihe",
                    type: "link",
                    title: "使用千千音乐搜索\"%s\"",
                    contexts: ["selection"],
                    payload: {
                        url: "http://music.taihe.com/search?key=%s"
                    },
                    default: "no"
                }
            ];
            return {
                title: "音乐搜索",
                list: menuList
            };
        };

        obj.getTranslateMenuList = function () {
            var menuList = [
                {
                    id: "translate_google",
                    type: "link",
                    title: "使用谷歌翻译\"%s\"",
                    contexts: ["selection"],
                    payload: {
                        url: "https://translate.google.cn/#view=home&op=translate&sl=auto&tl=zh-CN&text=%s"
                    },
                    default: "no"
                },
                {
                    id: "translate_baidu",
                    type: "link",
                    title: "使用百度翻译\"%s\"",
                    contexts: ["selection"],
                    payload: {
                        url: "https://fanyi.baidu.com/#zh/en/%s"
                    },
                    default: "no"
                }
            ];
            return {
                title: "文本翻译",
                list: menuList
            };
        };

        obj.getMoreMenuList = function () {
            var menuList = [
                {
                    id: "create_qrcode_select",
                    type: "create_qrcode_select",
                    title: "生成选中二维码",
                    contexts: ["selection"],
                    payload: {
                        size: 400
                    },
                    default: "yes"
                },
                {
                    id: "create_qrcode_link",
                    type: "create_qrcode_link",
                    title: "生成链接二维码",
                    contexts: ["link"],
                    payload: {
                        size: 400
                    },
                    default: "yes"
                },
                {
                    id: "create_qrcode_page",
                    type: "create_qrcode_page",
                    title: "生成页面二维码",
                    contexts: ["page"],
                    payload: {
                        size: 400
                    },
                    default: "yes"
                },
                {
                    id: "clear_browser_data",
                    type: "clear_browser_data",
                    title: "清理浏览器数据",
                    contexts: ["page"],
                    default: "no"
                }
            ];
            return {
                title: "常用工具",
                list: menuList
            };
        };

        obj.getDiyMenuList = function () {
            var diyMenuList = {
                title: "自定义搜索",
                list: []
            };
            var diyMenuArr = {};
            var menuText = obj.getSearchText();
            var rowList = menuText.split("\n");
            for (var i in rowList) {
                var text = rowList[i];
                if (text.indexOf("，") > 0) {
                    var item = text.split("，");
                    if (!diyMenuArr.hasOwnProperty(text)) {
                        diyMenuArr[text] = text;
                        diyMenuList["list"].push({
                            id: text,
                            type: "aria",
                            title: item[0],
                            contexts: ["selection"],
                            payload: {
                                url: item[1]
                            },
                            diy: true
                        });
                    }
                }
            }
            return diyMenuList;
        };

        obj.getAriaMenuList = function () {
            var ariaMenuList = {
                title: "导入到Aria",
                list: []
            };
            var ariaMenuArr = {};
            var menuText = obj.getAriaText();
            var rowList = menuText.split("\n");
            for (var i in rowList) {
                var text = rowList[i];
                if (text.indexOf("，") > 0) {
                    var item = text.split("，");
                    if (!ariaMenuArr.hasOwnProperty(text)) {
                        ariaMenuArr[text] = text;
                        ariaMenuList["list"].push({
                            id: text + "-link",
                            type: "aria",
                            title: item[0],
                            contexts: ["link"],
                            documentUrlPatterns: ["*://*.pcs.baidu.com/*"],
                            payload: {
                                server: item[1],
                                token: item[2]
                            },
                            diy: true
                        });
                        ariaMenuList["list"].push({
                            id: text + "-selection",
                            type: "aria",
                            title: item[0],
                            contexts: ["selection"],
                            payload: {
                                server: item[1],
                                token: item[2]
                            },
                            diy: true
                        });
                    }
                }
            }
            return ariaMenuList;
        };

        obj.getMenuList = function () {
            var menuList = [
                obj.getSearchMenuList(),
                obj.getShopSearchMenuList(),
                obj.getSocialSearchMenuList(),
                obj.getVideoSearchMenuList(),
                obj.getMusicSearchMenuList(),
                obj.getTranslateMenuList(),
                obj.getImageSearchMenuList(),
                obj.getMoreMenuList()
            ];
            try {
                var diyMenuList = obj.getDiyMenuList();
                diyMenuList.list.length && menuList.unshift(diyMenuList);

                var ariaMenuList = obj.getAriaMenuList();
                ariaMenuList.list.length && menuList.unshift(ariaMenuList);
            }
            catch (e) { }
            return menuList;
        };

        obj.getMenuMapping = function () {
            var menuMapping = {};
            var menuList = obj.getMenuList();
            for (var i in menuList) {
                for (var j in menuList[i]["list"]) {
                    var item = menuList[i]["list"][j];
                    menuMapping[item.id] = item;
                }
            }
            return menuMapping;
        };

        obj.initMenu = function () {
            addon.contextMenus.removeAll(function () {
                var menuList = obj.getMenuList();
                var menuMapping = obj.getMenuMapping();
                var optionList = obj.getMenuOption().getOption();
                var a = 0;
                for (var i in menuList) {
                    var b = 0;
                    for (var j in menuList[i]["list"]) {
                        var item = menuList[i]["list"][j];
                        if (optionList.indexOf(item.id) >= 0 || item.diy) {
                            if (a > 0 && b == 0) {
                                addon.contextMenus.create({
                                    type: "separator",
                                    contexts: item.contexts,
                                });
                            }
                            addon.contextMenus.create({
                                id: item.id,
                                title: item.title,
                                contexts: item.contexts,
                                onclick: function (info, tab) {
                                    var item = menuMapping[info.menuItemId];
                                    console.log(item, info, tab);
                                    obj.onClickMenu(item, info, tab);
                                }
                            });
                            a++ , b++;
                        }
                    }
                }
            });
        };

        obj.onClickMenu = function (item, info, tab) {
            switch (item.type) {
                case "link":
                    info.selectionText && obj.applyOpenLink(item.payload.url, info.selectionText);
                    break;
                case "search_similar_baidu":
                    info.linkUrl && obj.applySearchBaiduImage();
                    break;
                case "create_qrcode_select":
                    info.selectionText && obj.applyCreateQrcode(info.selectionText, item.payload.size);
                    break;
                case "create_qrcode_link":
                    info.linkUrl && obj.applyCreateQrcode(info.linkUrl, item.payload.size);
                    break;
                case "create_qrcode_page":
                    info.pageUrl && obj.applyCreateQrcode(info.pageUrl, item.payload.size);
                    break;
                case "clear_browser_data":
                    obj.applyClearBrowserData();
                    break;
                case "aria":
                    if (info.linkUrl) {
                        obj.applyAriaDownload(info.linkUrl, item.payload.server, item.payload.token);
                    }
                    else if (info.selectionText) {
                        obj.applyAriaDownload(info.selectionText, item.payload.server, item.payload.token);
                    }
                    break;
            }
        };

        obj.applyAriaDownload = function (text, server, token) {
            var urlList = text.split(" ");
            for (var i in urlList) {
                var url = urlList[i];
                if (url.indexOf("http") >= 0) {
                    aria.addTask("https://baidu.com", url, server, token, function (response) {
                        var info;
                        if (response && response.id) {
                            info = "导入链接到Aria成功";
                        }
                        else {
                            info = "导入链接到Aria失败";
                        }
                        notify.showNotify("集装箱", info, function () {
                            router.openTab("/page/aria/aria.html", true);
                        });
                    });
                }
            }
        };

        obj.applyOpenLink = function (url, keyword) {
            router.openTab(url.replace(/%s/, encodeURIComponent(keyword)));
        };

        obj.applySearchBaiduImage = function (url) {
            api.queryBaiduImage(url, function (response) {
                if (response && response.status == 0) {
                    router.openTab(response.data.url);
                }
            });
        };

        obj.applyCreateQrcode = function (text, size) {
            router.openTab("http://api.newday.me/share/image/qrcode?text=" + encodeURIComponent(text) + "&size=" + size);
        };

        obj.applyClearBrowserData = function () {
            if (browser.getBrowser() == browser.constant.firefox) {
                router.openTab("about:preferences#privacy");
            }
            else {
                router.openTab("chrome://settings/clearBrowserData");
            }
        };

        return obj;
    });

    container.define("bridge", ["message_addon", "storage", "loader", "router", "http", "gm", "proxy", "menu"], function (messageAddon, storage, loader, router, http, gm, proxy, menu) {
        var obj = {};

        obj.onSetValue = function (data, callback) {
            if (data._name_) {
                data.name = data._name_ + "_" + data.name;
            }

            storage.setValue(data.name, data.value);
            callback && callback("ok");
        };

        obj.onGmInit = function (data, callback) {
            var response = {
                gm_info: gm.getGmInfo(),
                gm_values: gm.getGmValues()
            };
            callback && callback(response);
        };

        obj.onOpenTab = function (data, callback) {
            router.openTab(data.url, data.active);
            callback && callback("ok");
        };

        obj.onAjaxRequest = function (data, callback) {
            var option;
            if (data.mode == "gm") {
                option = {
                    url: data.url,
                    dataType: data.responseType
                };

                // 请求数据
                if (data.data) {
                    option.type = "post";
                    option.data = data.data;
                }
                else {
                    option.type = "get";
                }

                // 请求头
                if (data.headers) {
                    option.headers = data.headers;
                }

                // 超时
                if (data.timeout) {
                    option.timeout = data.timeout;
                }
            }
            else {
                option = data;
            }

            option.success = function (result) {
                callback && callback(result);
            };
            option.error = function (error) {
                callback && callback("");
            };
            http.ajax(option);
        };

        obj.onLoadScript = function (data, callback) {
            loader.loadScript(data.url_list, callback);
        };

        obj.onBuildScript = function (data, callback) {
            loader.buildScript(data.template_list, data.lib_list, data.gm_list, callback);
        };

        obj.onGetProxyStatus = function (data, callback) {
            callback && callback({
                status: proxy.getStatus()
            });
        };

        obj.onSetProxyStatus = function (data, callback) {
            proxy.setStatus(data.status);
            proxy.initProxy();
            callback && callback("ok");
        };

        obj.onGetMenuOption = function (data, callback) {
            callback && callback({
                option: menu.getMenuOption().getOption(),
                search_text: menu.getSearchText(),
                aria_text: menu.getAriaText()
            });
        };

        obj.onSetMenuOption = function (data, callback) {
            menu.getMenuOption().setOption(data.option);
            menu.setSearchText(data.search_text);
            menu.setAriaText(data.aria_text);

            menu.initMenu();
            callback && callback("ok");
        };

        obj.init = function () {
            // 设置值
            messageAddon.onMessage("set_value", obj.onSetValue);

            // 脚本初始化
            messageAddon.onMessage("gm_init", obj.onGmInit);

            // 打开窗口
            messageAddon.onMessage("open_tab", obj.onOpenTab);

            // 网络请求
            messageAddon.onMessage("ajax_request", obj.onAjaxRequest);

            // 加载脚本
            messageAddon.onMessage("load_script", obj.onLoadScript);

            // 构造脚本
            messageAddon.onMessage("build_script", obj.onBuildScript);

            // 代理状态
            messageAddon.onMessage("get_proxy_status", obj.onGetProxyStatus);

            // 设置代理状态
            messageAddon.onMessage("set_proxy_status", obj.onSetProxyStatus);

            // 获取菜单配置
            messageAddon.onMessage("get_menu_option", obj.onGetMenuOption);

            // 设置菜单配置
            messageAddon.onMessage("set_menu_option", obj.onSetMenuOption);
        };

        return {
            init: obj.init
        };
    });

    container.define("core", ["addon", "config", "router", "updater", "bridge", "proxy", "command", "menu", "aria"], function (addon, config, router, updater, bridge, proxy, command, menu, aria) {
        var obj = {};

        obj.openOptionPage = function () {
            var manifest = addon.runtime.getManifest();
            router.openTab(manifest.options_page, true);
        };

        obj.initInstall = function () {
            var optionDate = config.getConfig("option_date");
            var optionDateCurrent = 20191120;
            if (!optionDate || optionDate < optionDateCurrent) {
                config.setConfig("option_date", optionDateCurrent);
                obj.openOptionPage();
            }
        };

        obj.initVersion = function () {
            updater.init();
        };

        obj.initBridge = function () {
            bridge.init();
        };

        obj.initProxy = function () {
            proxy.initProxy();
            setInterval(proxy.initProxy, 1200000);
        };

        obj.initCommand = function () {
            command.init();
        };

        obj.initMenu = function () {
            menu.initMenu();
        };

        obj.ready = function (callback) {
            obj.initInstall();

            obj.initVersion();

            obj.initBridge();

            obj.initProxy();

            obj.initCommand();

            obj.initMenu();

            callback && callback();
        };

        return obj;
    });

    // lib
    container.define("$", [], function () {
        return window.$;
    });
    container.define("CryptoJS", [], function () {
        return CryptoJS;
    });

    container.use(["core"], function (core) {
        core.ready();
    });
})();