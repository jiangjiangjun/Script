class StringDelta {
    /**
     *
     * @param previous {string}
     * @param current {string}
     */
    constructor(previous, current) {
        this.previous = previous;
        this.current = current;
    }
}

export {StringDelta}