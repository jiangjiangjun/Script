class BooleanDelta {
    /**
     *
     * @param previous {boolean}
     * @param current {boolean}
     */
    constructor(previous, current) {
        this.previous = previous;
        this.current = current;
    }
}

export {BooleanDelta}