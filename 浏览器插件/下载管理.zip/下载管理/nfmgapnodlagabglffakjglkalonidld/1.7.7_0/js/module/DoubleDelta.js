class DoubleDelta {
    /**
     *
     * @param previous {number}
     * @param current {number}
     */
    constructor(previous, current) {
        this.previous = previous;
        this.current = current;
    }
}

export {DoubleDelta}