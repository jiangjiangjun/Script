function checkPotentialPopup(a, b, c) {
	var d = extractHostFromURL(b), e = extractHostFromURL(c), f = isThirdParty(
			d, e), g = defaultMatcher.matchesAny(b || "about:blank", "POPUP",
			e, f);
	g instanceof BlockingFilter && chrome.tabs.remove(a)
}
if ("webNavigation" in chrome) {
	var tabsLoading = {};
	chrome.webNavigation.onCreatedNavigationTarget.addListener(function(a) {
				if (!isFrameWhitelisted(a.sourceTabId, a.sourceFrameId)) {
					var b = getFrameUrl(a.sourceTabId, a.sourceFrameId);
					b
							&& (tabsLoading[a.tabId] = b, checkPotentialPopup(
									a.tabId, a.url, b))
				}
			}), chrome.tabs.onUpdated.addListener(function(a, b, c) {
		a in tabsLoading
				&& ("url" in b && checkPotentialPopup(a, c.url, tabsLoading[a]), "status" in b
						&& "complete" == b.status
						&& "about:blank" != c.url
						&& delete tabsLoading[a])
	})
}