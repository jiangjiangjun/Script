function loadOptions() {
	document.title = i18n.getMessage("options"), setLinks(
			"filter-must-follow-syntax",
			"http://dev.start-up-fast.com/extension/filtersyntax.html"), setLinks(
			"rule-subscription-advice",
			"http://dev.start-up-fast.com/help/index.html#help2-6"), window
			.addEventListener("unload", unloadOptions, !1), $("#updateFilterLists")
			.click(updateFilterLists), $("#startSubscriptionSelection")
			.click(startSubscriptionSelection), $("#subscriptionSelector")
			.change(updateSubscriptionSelection), $("#addSubscription")
			.click(addSubscription), $("#whitelistForm")
			.submit(addWhitelistDomain), $("#removeWhitelist")
			.click(removeSelectedExcludedDomain), $("#customFilterForm")
			.submit(addTypedFilter), $("#removeCustomFilter")
			.click(removeSelectedFilters), $("#rawFiltersButton")
			.click(toggleFiltersInRawFormat), $("#importRawFilters")
			.click(importRawFiltersText), $("#startScriptSelection")
			.click(startScriptSelection), $("#scriptSelector")
			.change(updateScriptSelection), $("#addScript").click(addScript), $("#updateCsxript")
			.click(updateCsxript), FilterNotifier.addListener(onFilterChange), initCheckbox(
			"shouldShowIcon", !0), initCheckbox("shouldShowBlockElementMenu",
			!0), initCheckbox("hidePlaceholders", !0), initCheckbox("debug", !1), initCheckbox(
			"notificationRules", !1), $("#reloadextension").click(function() {
				chrome.runtime.reload()
			}), loadRecommendations(), loadRecommendationScript(), reloadFilters()
}
function reloadFilters() {
	for (var a = document.getElementById("filterLists"); a.lastChild;)
		a.removeChild(a.lastChild);
	for (var b = 0; b < FilterStorage.subscriptions.length; b++) {
		var c = FilterStorage.subscriptions[b];
		c instanceof SpecialSubscription || addSubscriptionEntry(c)
	}
	for (var d = Cscript.cscripts.list, b = 0; b < d.length; b++) {
		var e = i18n_timeDateStrings(d[b].lastCheck), f = e[1]
				? "last_updated_at"
				: "last_updated_at_today", g = i18n.getMessage(f, e);
		void 0 == d[b].enabled && (d[b].enabled = !0), addCscript(d[b].title,
				d[b].link, d[b].homepage, g, d[b].enabled)
	}
	$(document).on("click", ".rscript", function() {
				Cscript.remove($(this).next().next().attr("title"))
			}), $(document).on("click", ".cscriptEnabled", function() {
		Cscript.enable($(this).parent().next().attr("title"), $(this)
						.is(":checked"))
	}), showUserFilters()
}
function unloadOptions() {
	FilterNotifier.removeListener(onFilterChange)
}
function initCheckbox(a, b) {
	var c = document.getElementById(a);
	"undefined" == typeof localStorage[a] && (localStorage[a] = b), c.checked = "true" == localStorage[a], c
			.addEventListener("click", function() {
						localStorage[a] = c.checked
					}, !1)
}
function showUserFilters() {
	for (var a = [], b = [], c = 0; c < FilterStorage.subscriptions.length; c++) {
		var d = FilterStorage.subscriptions[c];
		if (d instanceof SpecialSubscription)
			for (var e = 0; e < d.filters.length; e++) {
				var f = d.filters[e];
				f instanceof WhitelistFilter
						&& /^@@\|\|([^\/:]+)\^\$document$/.test(f.text) ? b
						.push(RegExp.$1) : a.push(f.text)
			}
	}
	populateList("userFiltersBox", a), populateList("excludedDomainsBox", b)
}
function loadRecommendations() {
	var a = new XMLHttpRequest;
	a.open("GET", "subscriptions.xml"), a.onload = function() {
		for (var b = 0, e = document.getElementById("subscriptionSelector"), f = a.responseXML.documentElement
				.getElementsByTagName("subscription"), g = 0; g < f.length; g++) {
			var h = f[g], i = new Option;
			i.text = h.getAttribute("title") + " ("
					+ h.getAttribute("specialization") + ")", i._data = {
				title : h.getAttribute("title"),
				url : h.getAttribute("url"),
				homepage : h.getAttribute("homepage")
			}, e.appendChild(i)
		}
		var i = new Option;
		i.text = i18n.getMessage("filters_addSubscriptionOther_label")
				+ "\u2026", i._data = null, e.appendChild(i), e.selectedIndex = b, delayedSubscriptionSelection
				&& startSubscriptionSelection.apply(null,
						delayedSubscriptionSelection)
	}, a.send(null)
}
function loadRecommendationScript() {
	var a = new XMLHttpRequest;
	a.open("GET", "http://sub.adtchrome.com/subscriptions.xml"), a.onload = function() {
		for (var b = 0, e = document.getElementById("scriptSelector"), f = a.responseXML.documentElement
				.getElementsByTagName("script"), g = 0; g < f.length; g++) {
			var h = f[g], i = new Option;
			i.text = h.getAttribute("title"), i._data = {
				title : h.getAttribute("title"),
				url : h.getAttribute("url")
			}, e.appendChild(i)
		}
		var i = new Option;
		i.text = i18n.getMessage("filters_addSubscriptionOther_label")
				+ "\u2026", i._data = null, e.appendChild(i), e.selectedIndex = b, delayedSubscriptionSelection
				&& startSubscriptionSelection.apply(null,
						delayedSubscriptionSelection)
	}, a.send(null)
}
function startSubscriptionSelection(a, b) {
	var c = document.getElementById("subscriptionSelector");
	return 0 == c.length
			? (delayedSubscriptionSelection = [a, b], void 0)
			: ($("#addSubscriptionContainer").show(), $("#addSubscriptionButton")
					.hide(), $("#subscriptionSelector").focus(), "undefined" != typeof b
					&& (c.selectedIndex = c.length - 1, document
							.getElementById("customSubscriptionTitle").value = a, document
							.getElementById("customSubscriptionLocation").value = b), updateSubscriptionSelection(), document
					.getElementById("addSubscriptionContainer")
					.scrollIntoView(!0), void 0)
}
function startScriptSelection() {
	$("#addScriptContainer").show(), $("#addScriptButton").hide(), $("#subscriptSelector")
			.focus()
}
function updateSubscriptionSelection() {
	var a = document.getElementById("subscriptionSelector"), b = a.options[a.selectedIndex]._data;
	b
			? $("#customSubscriptionContainer").hide()
			: ($("#customSubscriptionContainer").show(), $("#customSubscriptionTitle")
					.focus())
}
function updateScriptSelection() {
	var a = document.getElementById("scriptSelector"), b = a.options[a.selectedIndex]._data;
	b ? $("#customScriptContainer").hide() : ($("#customScriptContainer")
			.show(), $("#customScriptTitle").focus())
}
function addSubscription() {
	var a = document.getElementById("subscriptionSelector"), b = a.options[a.selectedIndex]._data;
	if (b)
		doAddSubscription(b.url, b.title, b.homepage);
	else {
		var c = document.getElementById("customSubscriptionLocation").value
				.replace(/^\s+/, "").replace(/\s+$/, "");
		if (!/^https?:/i.test(c))
			return alert(i18n
					.getMessage("global_subscription_invalid_location")), $("#customSubscriptionLocation")
					.focus(), void 0;
		var d = document.getElementById("customSubscriptionTitle").value
				.replace(/^\s+/, "").replace(/\s+$/, "");
		d || (d = c), doAddSubscription(c, d, null)
	}
	$("#addSubscriptionContainer").hide(), $("#customSubscriptionContainer")
			.hide(), $("#addSubscriptionButton").show()
}
function updateCsxript() {
	Cscript.execute()
}
function addScript() {
	var a = document.getElementById("scriptSelector"), b = a.options[a.selectedIndex]._data;
	if (b)
		doAddScript(b.url, b.title);
	else {
		var c = document.getElementById("customScriptLocation").value.replace(
				/^\s+/, "").replace(/\s+$/, "");
		if (!/^https?:/i.test(c))
			return alert(i18n
					.getMessage("global_subscription_invalid_location")), $("#customScriptLocation")
					.focus(), void 0;
		var d = document.getElementById("customScriptTitle").value.replace(
				/^\s+/, "").replace(/\s+$/, "");
		d || (d = c), doAddScript(c, d)
	}
	$("#addScriptContainer").hide(), $("#customScriptContainer").hide(), $("#addScriptButton")
			.show()
}
function doAddSubscription(a, b, c) {
	if (!(a in FilterStorage.knownSubscriptions)) {
		var d = Subscription.fromURL(a);
		d
				&& (d.title = b, c && (d.homepage = c), FilterStorage
						.addSubscription(d), d instanceof DownloadableSubscription
						&& !d.lastDownload && Synchronizer.execute(d))
	}
}
function doAddScript(a, b) {
	Cscript.add(b, a)
}
function findSubscriptionElement(a) {
	for (var b = document.getElementById("filterLists").childNodes, c = 0; c < b.length; c++)
		if (b[c]._subscription == a)
			return b[c];
	return null
}
function updateSubscriptionInfo(a) {
	var b = a._subscription, c = a.getElementsByClassName("subscriptionTitle")[0];
	c.textContent = b.title, c.setAttribute("title", b.url), c.href = b.homepage
			? b.homepage
			: b.url;
	var d = a.getElementsByClassName("subscriptionEnabled")[0];
	d.checked = !b.disabled;
	var e = a.getElementsByClassName("subscriptionUpdate")[0];
	if (e.classList.remove("error"), Synchronizer.isExecuting(b.url))
		e.textContent = i18n
				.getMessage("filters_subscription_lastDownload_inProgress");
	else if (b.downloadStatus && "synchronize_ok" != b.downloadStatus) {
		var f = {
			synchronize_invalid_url : "filters_subscription_lastDownload_invalidURL",
			synchronize_connection_error : "filters_subscription_lastDownload_connectionError",
			synchronize_invalid_data : "filters_subscription_lastDownload_invalidData",
			synchronize_checksum_mismatch : "filters_subscription_lastDownload_checksumMismatch"
		};
		e.textContent = b.downloadStatus in f ? i18n
				.getMessage(f[b.downloadStatus]) : b.downloadStatus, e.classList
				.add("error")
	} else if (b.lastDownload > 0) {
		var g = i18n_timeDateStrings(1e3 * b.lastDownload), h = g[1]
				? "last_updated_at"
				: "last_updated_at_today";
		e.textContent = i18n.getMessage(h, g)
	}
}
function onFilterChange(a, b, c) {
	switch (console.log(a), a) {
		case "load" :
			reloadFilters();
			break;
		case "subscription.title" :
		case "subscription.disabled" :
		case "subscription.homepage" :
		case "subscription.lastDownload" :
		case "subscription.downloadStatus" :
			var e = findSubscriptionElement(b);
			e && updateSubscriptionInfo(e);
			break;
		case "subscription.added" :
			if (b instanceof SpecialSubscription)
				for (var f = 0; f < b.filters.length; f++)
					onFilterChange("filter.added", b.filters[f]);
			else
				findSubscriptionElement(b) || addSubscriptionEntry(b);
			break;
		case "subscription.removed" :
			if (b instanceof SpecialSubscription)
				for (var f = 0; f < b.filters.length; f++)
					onFilterChange("filter.removed", b.filters[f]);
			else {
				var e = findSubscriptionElement(b);
				e && e.parentNode.removeChild(e)
			}
			break;
		case "filter.added" :
			b instanceof WhitelistFilter
					&& /^@@\|\|([^\/:]+)\^\$document$/.test(b.text)
					? appendToListBox("excludedDomainsBox", RegExp.$1)
					: appendToListBox("userFiltersBox", b.text);
			break;
		case "filter.removed" :
			b instanceof WhitelistFilter
					&& /^@@\|\|([^\/:]+)\^\$document$/.test(b.text)
					? removeFromListBox("excludedDomainsBox", RegExp.$1)
					: removeFromListBox("userFiltersBox", b.text);
			break;
		case "cscript.added" :
			addCscript(b, c, c, "\u6b63\u5728\u4e0b\u8f7d...", !0);
			break;
		case "cscript.downloadStart" :
			$('[title="' + b.link + '"]').next()
					.html("\u6b63\u5728\u4e0b\u8f7d...");
			break;
		case "cscript.downloadStatus" :
			var g = i18n_timeDateStrings(b.lastCheck), h = g[1]
					? "last_updated_at"
					: "last_updated_at_today", i = i18n.getMessage(h, g);
			$('[title="' + b.link + '"]').next().html(i);
			break;
		case "cscript.removed" :
			$('[title="' + b + '"]').parent().remove()
	}
}
function populateList(a, b) {
	for (var c = document.getElementById(a); c.lastChild;)
		c.removeChild(c.lastChild);
	b.sort();
	for (var d = 0; d < b.length; d++) {
		var e = new Option;
		e.text = b[d], e.value = b[d], c.appendChild(e)
	}
}
function appendToListBox(a, b) {
	var c = new Option;
	c.text = b, c.value = b, document.getElementById(a).appendChild(c)
}
function removeFromListBox(a, b) {
	for (var c = document.getElementById(a), d = 0; d < c.length; d++)
		c.options[d].value == b && c.remove(d--)
}
function addWhitelistDomain(a) {
	a.preventDefault();
	var b = document.getElementById("newWhitelistDomain").value.replace(/\s/g,
			"");
	if (document.getElementById("newWhitelistDomain").value = "", b) {
		var c = "@@||" + b + "^$document";
		FilterStorage.addFilter(Filter.fromText(c))
	}
}
function addTypedFilter(a) {
	a.preventDefault();
	var b = Filter.normalize(document.getElementById("newFilter").value);
	document.getElementById("newFilter").value = "", b
			&& FilterStorage.addFilter(Filter.fromText(b))
}
function removeSelectedExcludedDomain() {
	for (var a = document.getElementById("excludedDomainsBox"), b = [], c = 0; c < a.length; c++)
		a.options[c].selected && b.push(a.options[c].value);
	if (b.length)
		for (var c = 0; c < b.length; c++)
			FilterStorage.removeFilter(Filter.fromText("@@||" + b[c]
					+ "^$document"))
}
function removeSelectedFilters() {
	for (var a = document.getElementById("userFiltersBox"), b = [], c = 0; c < a.length; c++)
		a.options[c].selected && b.push(a.options[c].value);
	if (b.length)
		for (var c = 0; c < b.length; c++)
			FilterStorage.removeFilter(Filter.fromText(b[c]))
}
function toggleFiltersInRawFormat(a) {
	if (a.preventDefault(), $("#rawFilters").toggle(), $("#rawFilters")
			.is(":visible")) {
		for (var b = document.getElementById("userFiltersBox"), c = "", d = 0; d < b.length; d++)
			c += b.options[d].value + "\n";
		document.getElementById("rawFiltersText").value = c
	}
}
function importRawFiltersText() {
	$("#rawFilters").hide();
	for (var a = document.getElementById("rawFiltersText").value.split("\n"), b = {
		__proto__ : null
	}, c = 0; c < a.length; c++) {
		var d = Filter.normalize(a[c]);
		d
				&& (/^\[/.test(d) || (FilterStorage.addFilter(Filter
						.fromText(d)), b[d] = !0))
	}
	for (var e = [], c = 0; c < FilterStorage.subscriptions.length; c++) {
		var f = FilterStorage.subscriptions[c];
		if (f instanceof SpecialSubscription)
			for (var g = 0; g < f.filters.length; g++) {
				var h = f.filters[g];
				h instanceof WhitelistFilter
						&& /^@@\|\|([^\/:]+)\^\$document$/.test(h.text)
						|| h.text in b || e.push(h)
			}
	}
	for (var c = 0; c < e.length; c++)
		FilterStorage.removeFilter(e[c])
}
function updateFilterLists() {
	for (var a = 0; a < FilterStorage.subscriptions.length; a++) {
		var b = FilterStorage.subscriptions[a];
		b instanceof DownloadableSubscription
				&& Synchronizer.execute(b, !0, !0)
	}
}
function addSubscriptionEntry(a) {
	var b = document.getElementById("subscriptionTemplate"), c = b
			.cloneNode(!0);
	c.removeAttribute("id"), c._subscription = a;
	var d = c.getElementsByClassName("subscriptionRemoveButton")[0];
	a.url.indexOf("adt-chinalist-easylist.txt") > 0
			? (d.className += " undisable", d.textContent = "")
			: (d.textContent = "\xd7", d.setAttribute("title", d.textContent), d
					.addEventListener("click", function() {
						confirm(i18n
								.getMessage("global_remove_subscription_warning"))
								&& FilterStorage.removeSubscription(a)
					}, !1));
	var e = c.getElementsByClassName("subscriptionEnabled")[0];
	e.addEventListener("click", function() {
				a.disabled != !e.checked && (a.disabled = !e.checked)
			}, !1), updateSubscriptionInfo(c), document
			.getElementById("filterLists").appendChild(c)
}
function addCscript(a, b, c, d, e) {
	var f = document.getElementById("scriptList"), g = document
			.createElement("div"), h = e ? 'checked="checked"' : "";
	if (b.indexOf("videoadjs.txt") > 0)
		var i = '<button class="subscriptionRemoveButton rscript undisable"></button> ';
	else
		var i = '<button class="subscriptionRemoveButton rscript">x</button> ';
	g.setAttribute("class", "subscription"), g.innerHTML = i
			+ '<span class="subscriptionEnabledContainer"><input class="subscriptionEnabled cscriptEnabled" type="checkbox" '
			+ h
			+ '> <span class="i18n_filters_subscription_enabled_label">\u542f\u7528</span></span>                          <a class="subscriptionTitle" title="'
			+ b + '" href="' + c + '">' + a
			+ '</a><span class="subscriptionUpdate">' + d + "</span>", f
			.appendChild(g)
}
function setLinks(a) {
	var b = document.getElementById(a);
	if (b)
		for (var c = b.getElementsByTagName("a"), d = 0; d < c.length; d++)
			"string" == typeof arguments[d + 1]
					? (c[d].href = arguments[d + 1], c[d].setAttribute(
							"target", "_blank"))
					: "function" == typeof arguments[d + 1]
							&& (c[d].href = "javascript:void(0);", c[d]
									.addEventListener("click",
											arguments[d + 1], !1))
}
$(document).on("click.tab.data-api", '[data-toggle="tab"]', function() {
	if (!$(this).parent("li").hasClass("active")) {
		var b = $(this).parent().siblings(".active");
		b.removeClass("active"), $(this).parent().addClass("active"), $(b
				.children("a").attr("href")).hide(), $($(this).attr("href"))
				.show(), window.location.hash = $(this).attr("href")
	}
}), $(document).ready(function() {
			$('[data-toggle="tab"][href="' + window.location.hash + '"]')
					.click()
		});
var backgroundPage = chrome.extension.getBackgroundPage(), require = backgroundPage.require;
with (require("filterClasses"))
	this.Filter = Filter, this.WhitelistFilter = WhitelistFilter;
with (require("subscriptionClasses"))
	this.Subscription = Subscription, this.SpecialSubscription = SpecialSubscription, this.DownloadableSubscription = DownloadableSubscription;
var FilterStorage = require("filterStorage").FilterStorage, FilterNotifier = require("filterNotifier").FilterNotifier, Synchronizer = require("synchronizer").Synchronizer, Utils = require("utils").Utils, Cscript = require("cscript").Cscript;
$(loadOptions);
var delayedSubscriptionSelection = null;