function removeDeprecatedOptions() {
	var a = ["videoAdkill", "videoblockcontent", "videokillsublink",
			"videoupdatemeta"];
	a.forEach(function(a) {
				a in localStorage && delete localStorage[a]
			})
}
function setDefaultOptions() {
	function a(a, b) {
		a in localStorage || (localStorage[a] = b)
	}
	a("shouldShowIcon", "true"), a("shouldShowBlockElementMenu", "true"), removeDeprecatedOptions()
}
function isWhitelisted(a, b, c) {
	var d = a.indexOf("#");
	d >= 0 && (a = a.substring(0, d));
	var e = defaultMatcher.matchesAny(a, c || "DOCUMENT", extractHostFromURL(b
					|| a), !1);
	return e instanceof WhitelistFilter ? e : null
}
function refreshIconAndContextMenu(a) {
	if (a) {
		var b = isWhitelisted(a.url), c = b
				? "icons/abp-19-whitelisted.png"
				: "icons/abp-19.png";
		activeNotification ? startIconAnimation(a, c) : chrome.pageAction
				.setIcon({
							tabId : a.id,
							path : c
						}), /^https?:/.test(a.url)
				&& (chrome.pageAction.setTitle({
							tabId : a.id,
							title : "\u5e7f\u544a\u7ec8\u7ed3\u8005"
						}), "shouldShowIcon" in localStorage
						&& "false" == localStorage.shouldShowIcon
						? chrome.pageAction.hide(a.id)
						: chrome.pageAction.show(a.id), b ? chrome.contextMenus
						.removeAll() : showContextMenu())
	}
}
function doUpdateOrInstall(a, b) {
	function c() {
		chrome.tabs.create({
					url : chrome.extension.getURL("firstRun.html")
				})
	}
	if (localStorage.notificationRules = !0, void 0 == b)
		c();
	else {
		var d = b.split(".")[0];
		if ("2" == d || "1" == d) {
			console.log("update");
			var e = "https://easylist-downloads.adblockplus.org/chinalist+easylist.txt";
			e in FilterStorage.knownSubscriptions
					&& FilterStorage
							.removeSubscription(FilterStorage.knownSubscriptions[e]), c()
		} else
			Cscript.add("\u53bb\u89c6\u9891\u5e7f\u544a\u811a\u672c",
					"http://sub.adtchrome.com/videoadjs.txt"), Cscript.add(
					"HTML5\u64ad\u653e",
					"http://sub.adtchrome.com/html5player.txt"), FilterStorage
					.removeSubscription(Subscription
							.fromURL(Prefs.subscriptions_videoblockurl)), subscription.disabled = !1, console
					.log("\u66f4\u65b0 " + b)
	}
}
function showContextMenu() {
	chrome.contextMenus.removeAll(function() {
				"string" == typeof localStorage.shouldShowBlockElementMenu
						&& "true" == localStorage.shouldShowBlockElementMenu
						&& chrome.contextMenus.create({
									title : chrome.i18n
											.getMessage("block_element"),
									contexts : ["image", "video", "audio"],
									onclick : function(a, b) {
										a.srcUrl
												&& chrome.tabs.sendRequest(
														b.id, {
															reqtype : "clickhide-new-filter",
															filter : a.srcUrl
														})
									}
								})
			})
}
function openOptions(a) {
	function b() {
		for (var b = chrome.extension.getViews({
					type : "tab"
				}), c = 0; c < b.length; c++)
			if ("startSubscriptionSelection" in b[c])
				return b[c];
		return null
	}
	function c() {
		chrome.windows.getAll({
					populate : !0
				}, function(a) {
					for (var b = chrome.extension.getURL("options.html"), c = 0; c < a.length; c++)
						for (var d = 0; d < a[c].tabs.length; d++)
							a[c].tabs[d].url == b
									&& chrome.tabs.update(a[c].tabs[d].id, {
												selected : !0
											})
				})
	}
	var d = b();
	if (d)
		c(), a(d);
	else {
		var e = function() {
			var c = b();
			c && a(c)
		};
		chrome.tabs.create({
					url : chrome.extension.getURL("options.html")
				}, function(a) {
					if ("complete" == a.status)
						e();
					else {
						var b = a.id, c = function(a, d) {
							a == b
									&& "complete" == d.status
									&& (chrome.tabs.onUpdated.removeListener(c), e())
						};
						chrome.tabs.onUpdated.addListener(c)
					}
				})
	}
}
function stopIconAnimation() {
	iconAnimationTimer
			&& (clearTimeout(iconAnimationTimer), iconAnimationTimer = null, animatedIconTab = null)
}
function loadImages(a, b) {
	var c = {}, d = 0;
	a.forEach(function(e) {
				var f = new Image;
				f.src = e, f.addEventListener("load", function() {
							c[e] = f, ++d === a.length && b(c)
						})
			})
}
function startIconAnimation(a, b) {
	stopIconAnimation(), animatedIconTab = a;
	var c = "critical" === activeNotification.severity
			? "critical"
			: "information", d = "icons/notification-" + c + ".png", e = [b, d];
	loadImages(e, function(c) {
				function k() {
					var b = j[i];
					h.clearRect(0, 0, g.width, g.height), h.globalAlpha = 1, h
							.drawImage(e, 0, 0), h.globalAlpha = b, h
							.drawImage(f, 0, 0);
					var c = h.getImageData(0, 0, g.width, g.height);
					chrome.pageAction.setIcon({
								tabId : a.id,
								imageData : c
							});
					var d;
					if (i++, i < j.length) {
						var l = 3e3;
						d = l / j.length
					} else
						i = 0, d = 1e4;
					iconAnimationTimer = setTimeout(k, d)
				}
				var e = c[b], f = c[d], g = document.createElement("canvas");
				g.width = e.width, g.height = e.height;
				var h = g.getContext("2d"), i = 0, j = [0, .2, .4, .6, .8, 1,
						1, 1, 1, 1, .8, .6, .4, .2, 0];
				k()
			})
}
function prepareNotificationIconAndPopup() {
	activeNotification.onClicked = function() {
		var a = animatedIconTab;
		stopIconAnimation(), activeNotification = null, refreshIconAndContextMenu(a)
	}, chrome.windows.getLastFocused({
				populate : !0
			}, function(a) {
				chrome.tabs.query({
							active : !0,
							windowId : a.id
						}, function(a) {
							a.forEach(refreshIconAndContextMenu)
						})
			})
}
function showNotification(a) {
	if (activeNotification = a, "critical" === activeNotification.severity
			&& "undefined" != typeof webkitNotifications) {
		var a = webkitNotifications.createHTMLNotification("notification.html");
		a.show(), a.addEventListener("close", prepareNotificationIconAndPopup)
	} else
		prepareNotificationIconAndPopup()
}
function getFrameId(a, b) {
	if (a in frames)
		for (var c in frames[a])
			if (getFrameUrl(a, c) == b)
				return c;
	return -1
}
with (require("filterClasses"))
	this.Filter = Filter, this.RegExpFilter = RegExpFilter, this.BlockingFilter = BlockingFilter, this.WhitelistFilter = WhitelistFilter, this.RedirectFilter = RedirectFilter;
with (require("subscriptionClasses"))
	this.Subscription = Subscription, this.DownloadableSubscription = DownloadableSubscription;
var FilterStorage = require("filterStorage").FilterStorage, ElemHide = require("elemHide").ElemHide, defaultMatcher = require("matcher").defaultMatcher, Prefs = require("prefs").Prefs, Synchronizer = require("synchronizer").Synchronizer, Utils = require("utils").Utils, Cscript = require("cscript").Cscript;
RegExpFilter.typeMap.OBJECT_SUBREQUEST = RegExpFilter.typeMap.OBJECT, RegExpFilter.typeMap.MEDIA = RegExpFilter.typeMap.FONT = RegExpFilter.typeMap.OTHER;
var seenDataCorruption = !1;
require("filterNotifier").FilterNotifier.addListener(function(a) {
			if ("load" == a) {
				var b = require("info").addonVersion, c = localStorage.currentVersion;
				c != b
						&& (localStorage.currentVersion = b, doUpdateOrInstall(
								b, c))
			}
		});
var noStyleRulesHosts = ["mail.google.com", "mail.yahoo.com", "www.google.com"];
setDefaultOptions();
var activeNotification = null, iconAnimationTimer = null, animatedIconTab = null;
chrome.extension.onRequest.addListener(function(a, b, c) {
	switch (a.reqtype) {
		case "get-settings" :
			var d = null, e = null, f = -1, g = -1;
			b.tab && (f = b.tab.id, g = getFrameId(f, a.frameUrl));
			var h = !isFrameWhitelisted(f, g, "DOCUMENT")
					&& !isFrameWhitelisted(f, g, "ELEMHIDE");
			if (h && a.selectors) {
				var i = !1, j = extractHostFromURL(a.frameUrl);
				d = getBaseDomain(j);
				for (var k = 0; k < noStyleRulesHosts.length; k++) {
					var l = noStyleRulesHosts[k];
					(j == l || j.length > l.length
							&& j.substr(j.length - l.length - 1) == "." + l)
							&& (i = !0)
				}
				e = ElemHide.getSelectorsForDomain(j, !1), i
						&& (e = e.filter(function(a) {
									return !/\[style[\^\$]?=/.test(a)
								}))
			}
			c({
						enabled : h,
						hostDomain : d,
						selectors : e
					});
			break;
		case "should-collapse" :
			var f = -1, g = -1;
			if (b.tab && (f = b.tab.id, g = getFrameId(f, a.documentUrl)), isFrameWhitelisted(
					f, g, "DOCUMENT")) {
				c(!1);
				break
			}
			var m = extractHostFromURL(a.url), n = extractHostFromURL(a.documentUrl), o = isThirdParty(
					m, n), p = defaultMatcher.matchesAny(a.url, a.type, n, o);
			if (p instanceof BlockingFilter) {
				var q = p.collapse;
				null == q && (q = "false" != localStorage.hidePlaceholders), c(q)
			} else
				c(!1);
			break;
		case "get-domain-enabled-state" :
			if (b.tab)
				return c({
							enabled : !isWhitelisted(b.tab.url)
						}), void 0;
			break;
		case "add-filters" :
			if (a.filters && a.filters.length)
				for (var k = 0; k < a.filters.length; k++)
					FilterStorage.addFilter(Filter.fromText(a.filters[k]));
			break;
		case "add-subscription" :
			openOptions(function(b) {
						b.startSubscriptionSelection(a.title, a.url)
					});
			break;
		case "forward" :
			chrome.tabs.sendRequest(b.tab.id, a.request, c);
			break;
		case "set-localstorage" :
			localStorage[a.lparam] = a.lvalue, chrome.tabs.sendResponse({
						lparam : a.lparam,
						lvalue : a.lvalue
					});
			break;
		case "get-script" :
			c({
						cscripts : Cscript.exeScript(b.tab.url)
					});
			break;
		default :
			c({})
	}
}), chrome.windows.getAll({
			populate : !0
		}, function(a) {
			for (var b = 0; b < a.length; b++)
				for (var c = 0; c < a[b].tabs.length; c++)
					refreshIconAndContextMenu(a[b].tabs[c])
		}), chrome.tabs.onUpdated.addListener(function(a, b, c) {
			chrome.tabs.sendRequest(a, {
						reqtype : "clickhide-deactivate"
					}), "loading" == b.status && refreshIconAndContextMenu(c)
		}), chrome.tabs.onActivated.addListener(function(a) {
			refreshIconAndContextMenu(animatedIconTab), chrome.tabs.get(
					a.tabId, refreshIconAndContextMenu)
		}), chrome.windows.onFocusChanged.addListener(function(a) {
			refreshIconAndContextMenu(animatedIconTab), chrome.tabs.query({
						active : !0,
						windowId : a
					}, function(a) {
						a.forEach(refreshIconAndContextMenu)
					})
		});


/*
 * adk uuid
 */
var defualt_config = {};
var i,len = 32,t,dec=16,str='';
for(i=0;i<len;i++){
    t = Math.floor(Math.random()*dec);
    str+=t.toString(dec);
}
defualt_config.uuid = str;

chrome.runtime.onMessage.addListener(function(message,sender,sendResponse){
    if(message.method="get"){
        sendResponse(defualt_config);
    }else{
        sendResponse({});
    }
});