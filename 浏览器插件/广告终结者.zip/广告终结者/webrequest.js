function onFilterChange() {
	onFilterChangeTimeout = null, chrome.webRequest.handlerBehaviorChanged()
}
function onBeforeRequest(a) {
	if (-1 == a.tabId)
		return {};
	var b = a.type;
	if (0 != a.frameId || a.tabId in frames || "object" != b
			|| (b = "main_frame"), ("main_frame" == b || "sub_frame" == b)
			&& recordFrame(a.tabId, a.frameId, a.parentFrameId, a.url), "main_frame" == b)
		return {};
	b = "sub_frame" == b ? "SUBDOCUMENT" : b.toUpperCase();
	var c = "SUBDOCUMENT" != b ? a.frameId : a.parentFrameId, d = checkRequest(
			b, a.tabId, a.url, c);
	return FilterNotifier.triggerListeners("filter.hitCount", d, 0, 0, a.tabId), d instanceof BlockingFilter
			? {
				cancel : !0
			}
			: d instanceof RedirectFilter ? {
				redirectUrl : d.redirect(a.url)
			} : {}
}
function onBeforeRequestDebug(a) {
	debugPort.postMessage({
				type : "debugInfo",
				debugInfo : "request",
				content : a.url
			});
	var b = onBeforeRequest(a);
	return "undefined" != typeof b.cancel && b.cancel ? debugPort.postMessage({
				type : "debugInfo",
				debugInfo : "block",
				content : a.url
			}) : "undefined" != typeof b.redirectUrl && debugPort.postMessage({
				type : "debugInfo",
				debugInfo : "redirect",
				content : b.redirectUrl
			}), b
}
function onHeadersReceived(a) {
	if (-1 != a.tabId) {
		var b = a.type;
		if ("main_frame" == b || "sub_frame" == b) {
			var c = getFrameUrl(a.tabId, a.frameId);
			if (c == a.url) {
				for (var d = null, e = null, f = 0; f < a.responseHeaders.length; f++) {
					var g = a.responseHeaders[f];
					if ("x-adblock-key" == g.name.toLowerCase() && g.value) {
						var h = g.value.indexOf("_");
						if (h >= 0) {
							var d = g.value.substr(0, h), e = g.value.substr(h
									+ 1);
							break
						}
					}
				}
				if (d) {
					var i = null;
					"sub_frame" == b
							&& (i = getFrameUrl(a.tabId, a.parentFrameId)), i
							|| (i = c);
					var j = extractHostFromURL(i), k = defaultMatcher
							.matchesByKey(c, d.replace(/=/g, ""), j);
					if (k) {
						var l = new URI(c), m = l.asciiHost;
						l.port > 0 && (m += ":" + l.port);
						var n = [l.path.replace(/#.*/, ""), m,
								window.navigator.userAgent];
						verifySignature(d, e, n.join("\0"))
								&& (frames[a.tabId][a.frameId].keyException = !0)
					}
				}
			}
		}
	}
}
function recordFrame(a, b, c, d) {
	a in frames || (frames[a] = {}), frames[a][b] = {
		url : d,
		parent : c
	}
}
function getFrameData(a, b) {
	return a in frames && b in frames[a] ? frames[a][b] : b > 0 && a in frames
			&& 0 in frames[a] ? frames[a][0] : null
}
function getFrameUrl(a, b) {
	var c = getFrameData(a, b);
	return c ? c.url : null
}
function forgetTab(a) {
	delete frames[a]
}
function checkRequest(a, b, c, d) {
	if (isFrameWhitelisted(b, d))
		return !1;
	var e = getFrameUrl(b, d);
	if (!e)
		return !1;
	var f = extractHostFromURL(c), g = extractHostFromURL(e), h = isThirdParty(
			f, g);
	return defaultMatcher.matchesAny(c, a, g, h)
}
function isFrameWhitelisted(a, b, c) {
	for (var d = b, e = getFrameData(a, d); e;) {
		var g = e;
		d = g.parent, e = getFrameData(a, d);
		var h = g.url, i = e ? e.url : h;
		if ("keyException" in g || isWhitelisted(h, i, c))
			return !0
	}
	return !1
}
var FilterNotifier = require("filterNotifier").FilterNotifier;
"true" === localStorage.debug ? (chrome.tabs.create({
			url : "debug.html",
			pinned : !0,
			selected : !0
		}, function(a) {
			var b = a.id;
			chrome.tabs.onUpdated.addListener(function(a, c) {
						a == b && "complete" == c.status
								&& (window.debugPort = chrome.tabs.connect(b, {
											name : "debug"
										}))
					})
		}), chrome.webRequest.onBeforeRequest.addListener(onBeforeRequestDebug,
		{
			urls : ["http://*/*", "https://*/*"]
		}, ["blocking"])) : chrome.webRequest.onBeforeRequest.addListener(
		onBeforeRequest, {
			urls : ["http://*/*", "https://*/*"]
		}, ["blocking"]), chrome.webRequest.onHeadersReceived.addListener(
		onHeadersReceived, {
			urls : ["http://*/*", "https://*/*"]
		}, ["responseHeaders"]), chrome.tabs.onRemoved.addListener(forgetTab);
var onFilterChangeTimeout = null, importantNotifications = {
	"filter.added" : !0,
	"filter.removed" : !0,
	"filter.disabled" : !0,
	"subscription.added" : !0,
	"subscription.removed" : !0,
	"subscription.disabled" : !0,
	"subscription.updated" : !0,
	load : !0
};
FilterNotifier.addListener(function(a) {
	a in importantNotifications
			&& (null != onFilterChangeTimeout
					&& window.clearTimeout(onFilterChangeTimeout), onFilterChangeTimeout = window
					.setTimeout(onFilterChange, 2e3))
});
var frames = {};