for (var backgroundPage = chrome.extension.getBackgroundPage(), imports = [
		"require", "isWhitelisted", "extractHostFromURL",
		"refreshIconAndContextMenu"], i = 0; i < imports.length; i++)
	window[imports[i]] = backgroundPage[imports[i]];
var require = backgroundPage.require, getStats = require("stats").getStats, FilterNotifier = require("filterNotifier").FilterNotifier, Filter = require("filterClasses").Filter, FilterStorage = require("filterStorage").FilterStorage, Prefs = require("prefs").Prefs, Cscript = require("cscript").Cscript;
with (require("subscriptionClasses"))
	this.Subscription = Subscription, this.DownloadableSubscription = DownloadableSubscription;
$(function() {
	function c() {
		chrome.tabs.query({
					active : !0,
					windowId : chrome.windows.WINDOW_ID_CURRENT
				}, function(b) {
					b.length > 0
							&& (a = b[0].id, d(), FilterNotifier.addListener(e))
				}), window.addEventListener("unload", function() {
					FilterNotifier.removeListener(e)
				}, !1)
	}
	function d() {
		var b = getStats("blocked", a).toLocaleString();
		$(".current-block-ad").html(b);
		var c = getStats("blocked").toLocaleString();
		$(".total-block-ad").html(c)
	}
	function e(a) {
		"filter.hitCount" == a && d()
	}
	function f() {
		chrome.windows.getCurrent(function(a) {
			chrome.tabs.getSelected(a.id, function(a) {
				b = a, isWhitelisted(b.url)
						|| ($("#enable-block").addClass("checked"), $("#enable-block-text")
								.show(), $("#disable-block-text").hide()), chrome.tabs
						.sendRequest(b.id, {
									reqtype : "get-clickhide-state"
								}, function(a) {
									a.active
											&& ($(".main-menu").hide(0), $(".click-block")
													.show(0))
								})
			})
		});
		var a = Cscript.getScript("http://sub.adtchrome.com/videoadjs.txt");
		void 0 != a
				&& a.enabled
				&& ($(".block-video-icon").toggleClass("checked"), $("#enable-video-block-text")
						.toggle(), $("#disable-video-block-text").toggle())
	}
	function g(a) {
		if (a)
			for (var c = isWhitelisted(b.url); c;)
				FilterStorage.removeFilter(c), c.subscriptions.length
						&& (c.disabled = !0), c = isWhitelisted(b.url);
		else {
			var d = extractHostFromURL(b.url).replace(/^www\./, ""), c = Filter
					.fromText("@@||" + d + "^$document");
			c.subscriptions.length && c.disabled
					? c.disabled = !1
					: (c.disabled = !1, FilterStorage.addFilter(c))
		}
		refreshIconAndContextMenu(b)
	}
	function h(a) {
		Cscript.enable("http://sub.adtchrome.com/videoadjs.txt", a)
	}
	function i() {
		chrome.tabs.sendRequest(b.id, {
					reqtype : "clickhide-activate"
				}), $("body").bind("mouseleave", function() {
					window.setTimeout(window.close, 500)
				})
	}
	function j() {
		$("body").unbind("mouseleave"), chrome.tabs.sendRequest(b.id, {
					reqtype : "clickhide-deactivate"
				})
	}
	function k(a) {
		var b, c = "", d = "\u5e7f\u544a\u7ec8\u7ed3\u8005(Ad Terminator)\u2014\u2014\u529f\u80fd\u6700\u5168\u9762\u7684\u5e7f\u544a\u5c4f\u853d\u6269\u5c55", e = "http://dev.start-up-fast.com/img/download-slide2.jpg", f = encodeURIComponent("http://dev.start-up-fast.com");
		switch (a) {
			case "sina-weibo" :
				b = "http://service.weibo.com/share/share.php?url=" + f
						+ "&appkey=" + c + "&title=" + d + "&pic=" + e;
				break;
			case "qq-zone" :
				b = "http://sns.qzone.qq.com/cgi-bin/qzshare/cgi_qzshare_onekey?url="
						+ f
						+ "&desc=\u5e7f\u544a\u7ec8\u7ed3\u8005(Ad Terminator)\u2014\u2014\u529f\u80fd\u6700\u5168\u9762\u7684\u5e7f\u544a\u5c4f\u853d\u63d2\u4ef6"
						+ "&title=\u5e7f\u544a\u7ec8\u7ed3\u8005(Ad Terminator)"
						+ "&pic=" + e;
				break;
			case "tenc-weibo" :
				b = "http://share.v.t.qq.com/index.php?c=share&a=index&url="
						+ f + "&title=" + d + "&appkey=" + c + "&pic=" + e;
				break;
			case "renren" :
				var g = "\u5e7f\u544a\u7ec8\u7ed3\u8005\u53ef\u4ee5\u6e05\u9664\u6240\u6709\u7f51\u9875\u5e7f\u544a\uff0c\u6076\u610f\u5f39\u7a97\uff0c\u89c6\u9891\u5e7f\u544a\uff0c\u8ddf\u8e2a\u4ee3\u7801\uff0c\u52a0\u5feb\u7f51\u9875\u52a0\u8f7d\u901f\u5ea6 ", h = "\u5e7f\u544a\u7ec8\u7ed3\u8005(Ad Terminator)\u2014\u2014\u529f\u80fd\u6700\u5168\u9762\u7684\u5e7f\u544a\u5c4f\u853d\u63d2\u4ef6";
				b = "http://widget.renren.com/dialog/share?resourceUrl=" + f
						+ "&message=" + h + "&description=" + g + "&pic=" + e
		}
		window.open(b)
	}
	function l() {
		$(".header").click(function() {
					$("#ad-statistic").show(), $("#menu").hide()
				}), $(".footer").click(function() {
					$("#ad-statistic").hide(), $("#menu").show()
				}), $(".checkbox-hoverhook").click(function() {
			$(this).find(".checkbox-green").toggleClass("checked"), $("#enable-block-text")
					.toggle(), $("#disable-block-text").toggle(), g($(this)
					.find(".checkbox-green").hasClass("checked"))
		}), $(".click-block-video-hook").click(function() {
			$(this).find(".block-video-icon").toggleClass("checked"), $("#enable-video-block-text")
					.toggle(), $("#disable-video-block-text").toggle(), h($(this)
					.find(".block-video-icon").hasClass("checked"))
		}), $(".checkbox-hoverhook").hover(function() {
					$(this).find(".checkbox-green").addClass("hover")
				}, function() {
					$(this).find(".checkbox-green").removeClass("hover")
				}), $(".option-hook").click(function() {
					window.close(), chrome.tabs.create({
								url : "options.html"
							})
				}), $(".click-help-hook").click(function() {
					window.open("http://dev.start-up-fast.com/help/index.html")
				}), $("#help-block").click(function() {
					window
							.open("http://dev.start-up-fast.com/help/help-block.html")
				}), $(".click-block-hook").click(function() {
					$(".main-menu").hide(), $(".click-block").show(), i()
				}), $("#click-block-cancel").click(function() {
					j(), $(".main-menu").show(), $(".click-block").hide()
				}), $(".sina-weibo").click(function() {
					k("sina-weibo")
				}), $(".qq-zone").click(function() {
					k("qq-zone")
				}), $(".tenc-weibo").click(function() {
					k("tenc-weibo")
				}), $(".renren").click(function() {
					k("renren")
				})
	}
	var a, b = null;
	f(), c(), l()
});